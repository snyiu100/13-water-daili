<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" title="合肖">
        <router-link to="/" slot="left" class="go-back"></router-link>  
        <span slot="right" class="cur"><router-link to="/rules">规则</router-link></span>
      </m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
         <bet-header></bet-header>
         <m-warp class="bgff">
            <div class="bet-tez clearfix "><ul class="bet-tez-check"><li :class="vm.check?'active':''" v-for="(vm,index) in lists.up" @click="tezActive(vm)" :key="index">{{vm.category}}</li></ul></div>
            <div class="bet-table">
               <div class="bet-table-hexiao bgff">
                  <ul class="clearfix bet-table-hexiao-header">
                    <li>号码</li>
                    <li>赔率</li>
                    <li>生肖</li>
                    <li>勾选</li>
                  </ul>
                  <ul class="clearfix" v-for="(vm,index) in lists.data" :key="index">
                    <li><span v-for="(arr,index) in vm.arr" :key="index" :class="'bet-bg-'+arr.cate">{{arr.key}}</span></li>
                    <li>{{vm.Odds}}</li>
                    <li>{{vm.category}}</li>
                    <li :class="vm.check?'active':''" @click="onOdd(vm)"></li>
                  </ul>
               </div>
            </div>
         </m-warp>
      </div>
      <bet-model v-model="isModel" @on-confirm="savePayBet" :inputShow="false" :info="betArr"></bet-model>
      <bet-footer></bet-footer>
  </div>

</template>

<script>
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import service from '@/common/service'
import {dates,shengXiaoCheckDate} from '@/common/bet'
import BetFooter from './betFooter'
import BetHeader from './betHeader'
import BetModel from './betModel'
export default {
  components:{
    MHeader,
    MWarp,
    BetFooter,
    BetHeader,
    BetModel
  },
  data () {
    return {
      lists:[],
      isModel:false,
      betArr:{bet:[],data:[]},
      info:{
        up:[{id:'',money:''}],
        down:[],
        betting_lx:[{type: 8,two_type: 0,three_type: 0,money: 0,fast:2}]
      }
    }
  },
  created(){   
    this.betShow();
  },
  methods:{
    tezActive(vm){
      let index = this.lists.up.indexOf(vm);
      for(let i in this.lists.up){
        this.lists.up[i].check=false;
      }
      this.info.betting_lx[0].two_type = vm.id;

      this.lists.up[index].check=true;
    },
   //选择种类
    onOdd(vm){
      if(this.teMaState==1) return false;
      let index = this.lists.data.indexOf(vm);
      if(vm.check){
          this.lists.data[index].check = false;
      }else{
         this.lists.data[index].check = true;
      }
    },
    getThinking(betlsit){
        let two_type = this.info.betting_lx[0].two_type,flag = true;
        if(two_type==39 && betlsit.length!=2){
          service.openToast(true,"二肖请选择2位数");
          flag = false;
        }
        if(two_type==49 && betlsit.length!=3){
          service.openToast(true,"三肖请选择3位数");
          flag = false;
        }
        if(two_type==50 && betlsit.length!=4){
          service.openToast(true,"四肖请选择4位数");
          flag = false;
        }
        if(two_type==51 && betlsit.length!=5){
          service.openToast(true,"五肖请选择5位数");
          flag = false;
        }
        if(two_type==52 && betlsit.length!=6){
          service.openToast(true,"六肖请选择6位数");
          flag = false;
        }
        if(two_type==53 && betlsit.length!=7){
          service.openToast(true,"七肖请选择7位数");
          flag = false;
        }        
        if(two_type==54 && betlsit.length!=8){
          service.openToast(true,"八肖请选择8位数");
          flag = false;
        }
        if(two_type==55 && betlsit.length!=9){
          service.openToast(true,"九肖请选择9位数");
          flag = false;
        }
        if(two_type==56 && betlsit.length!=10){
          service.openToast(true,"十肖请选择10位数");
          flag = false;
        } 
        if(two_type==57 && betlsit.length!=11){
          service.openToast(true,"十一肖请选择11位数");
          flag = false;
        } 
        return flag;
    }, 


    //获取数据  8:合肖
    betShow(){
      this.$http('bet/bet_show',{level:8}).then(res=>{
          if(res.code==200){
            for(let i in res.data){
              res.data[i].arr = dates[i];
              res.data[i].check = false;
            }
            for(let i in res.up){
              if(i==0){
                  res.up[i].check=true;
                  this.info.betting_lx[0].two_type = res.up[i].id;
              }else res.up[i].check = false;
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    //提交下注
    betSave(){
      this.info.down =  shengXiaoCheckDate(this.lists.data);
      if(this.info.down.length<1){
          service.openToast(true,"尚未选中");
          return false;
      } 
      if(this.getThinking(this.info.down)){
        service.betOrder(this.info).then(res=>{
            if(res.code==200){
                this.isModel = true;
                this.betArr = res;
            }else service.openToast(true,res.msg);
        }) 
      }



    },
    //弹出框下注
    savePayBet(){

    },
    //清空设置
    clearAll(){
        for(let i in this.lists.data){
            this.lists.data[i].check = false;
        }
        for(let i in this.lists.up){
          this.lists.up[i].check = false;
        }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

.bet-table-hexiao{
    border-top:1px solid #c6c6c6;

  ul{
    &.bet-table-hexiao-header{
      li{text-align: center; text-indent:0;   line-height:0.8rem;
        &:first-child{width:55%; text-align: center;}
        &::after{content: ""; border-right:1px solid #c6c6c6; float: right; height:0.8rem;}
        &:nth-child(4){ background: none;}
       }
    }
    border-bottom:1px solid #c6c6c6;
    li{ width:15%; float:left; text-align: center;  font-size:0.26rem;
      &:last-child::after{border-right:none; }
      &::after{content: ""; border-right:1px solid #c6c6c6; float: right; height:0.8rem;}
      &:nth-child(2),&:nth-child(3){line-height: 0.8rem;}
      &:nth-child(4){ background: url('../../assets/images/icon/checkbox.png') no-repeat center; background-size: 0.5rem; cursor: pointer;}
      &.active{ background: url('../../assets/images/icon/checkbox-active.png') no-repeat center; background-size: 0.5rem;}
      &:first-child{width:55%; text-align: left;
        span{background-color: #dd2638;  height:.45rem; margin: .18rem 0 0 .25rem; width:.45rem; line-height: .48rem; color:#fff; border-radius: 50%; display: inline-block; font-size:0.24rem; text-align: center;}
      }
    }
  }
}

</style>