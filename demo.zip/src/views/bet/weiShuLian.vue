<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" title="尾数连"><router-link to="/" slot="left" class="go-back"></router-link><span slot="right" class="cur"><router-link to="/rules">规则</router-link></span></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
          <bet-header></bet-header>
         <m-warp class="bgff">
            <div class="bet-tez clearfix bet-w-3"><ul class="bet-tez-check"><li :class="vm.check?'active':''" v-for="(vm,index) in lists.up" @click="tezActive(vm)" :key="index">{{vm.category}}</li></ul></div>
              <div class="bet-table ">
               <div class="bet-table-hexiao bgff">
                  <ul class="clearfix bet-table-hexiao-header">
                    <li>号码</li>
                    <li>赔率</li>
                    <li>尾数</li>
                    <li>勾选</li>
                  </ul>
                  <ul class="clearfix" v-for="(vm,index) in lists.data" :key="index">
                    <li><span v-for="(arr,index) in vm.arr" :key="index" :class="'bet-bg-'+arr.cate">{{arr.key}}</span></li>
                    <li>{{vm.Odds}}</li>
                    <li>{{vm.category}}尾</li>
                    <li :class="vm.check?'active':''" @click="onOdd(vm)"></li>
                  </ul>
               </div>
            </div>
         </m-warp>
      </div>
      <bet-model v-model="isModel" @on-confirm="savePayBet" :inputShow="false" :info="betArr"></bet-model>
      <bet-footer></bet-footer>
  </div>

</template>

<script>
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import BetFooter from './betFooter'
import BetHeader from './betHeader'
import {weiShuLianDate,shengXiaoCheckDate} from '@/common/bet'
import service from '@/common/service'
import BetModel from './betModel'
export default {
  components:{
    MHeader,
    MWarp,
    BetFooter,
    BetHeader,
    BetModel
  },
  data () {
    return {
      lists:[],
      betArr:{bet:[],data:[]},
      isModel:false,
      info:{
        up:JSON.stringify([{id:'',money:''}]),
        down:[],
        betting_lx:[{type:10,two_type:0,three_type: 0,money: '0',fast:2}]
      }
    }
  },
  created(){   
    this.betShow();
  },
  methods:{
    tezActive(vm){
      let index = this.lists.up.indexOf(vm);
      for(let i in this.lists.up){
        this.lists.up[i].check=false;
      }
      this.info.betting_lx[0].two_type = vm.id;
      this.lists.up[index].check=true;
    },
    //选择种类
    onOdd(vm){
      if(this.teMaState==1) return false;
      let index = this.lists.data.indexOf(vm);
      if(vm.check){
          this.lists.data[index].check = false;
      }else{
         this.lists.data[index].check = true;
      }
    },
    //获取数据  10:尾数连
    betShow(){
      this.$http('bet/bet_show',{level:10}).then(res=>{
          if(res.code==200){
            for(let i in res.data){
              res.data[i].arr = weiShuLianDate[i];
              res.data[i].check = false;
            }
            for(let i in res.up){
              if(i==0){
                res.up[i].check=true;
                this.info.betting_lx[0].two_type = res.up[i].id;
              }else res.up[i].check = false;
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    getThinking(betlsit){
        let two_type = this.info.betting_lx[0].two_type,flag = true;
        if(two_type==65 && betlsit.length!=2){
          service.openToast(true,"二尾连中请选择2位数");
          flag = false;
        }
        if(two_type==66 && betlsit.length!=3){
          service.openToast(true,"三尾连中请选择3位数");
          flag = false;
        }
        if(two_type==67 && betlsit.length!=4){
          service.openToast(true,"四尾连中请选择4位数");
          flag = false;
        }
        if(two_type==68 && betlsit.length!=2){
          service.openToast(true,"二尾连不中请选择2位数");
          flag = false;
        }
        if(two_type==69 && betlsit.length!=3){
          service.openToast(true,"三尾连不中请选择3位数");
          flag = false;
        }        
        if(two_type==70 && betlsit.length!=4){
          service.openToast(true,"四尾连不中请选择4位数");
          flag = false;
        }
        return flag;
    },    
    //提交下注
    betSave(){
      this.info.down =  shengXiaoCheckDate(this.lists.data);
      if(this.info.down.length<1){
          service.openToast(true,"尚未选中");
          return false;
      } 
      console.log('10:尾数连',this.info);
      if(this.getThinking(this.info.down)){
        service.betOrder(this.info).then(res=>{
            if(res.code==200){
                this.isModel = true;
                for(let i in res.bet){
                    res.bet[i].cate_num = res.bet[i].cate_num+'尾';
                }
                this.betArr = res;
            }else service.openToast(true,res.msg);
        })
      }


     /** this.$http('bet/bet_j',this.info,true).then(res=>{
          if(res.code==200){
            this.isModel = true;
            this.info.betting_lx = JSON.parse(this.info.betting_lx);
            for(let i in res.bet){
              res.bet[i].cate_num = res.bet[i].cate_num+'尾';
            }
            this.betArr = res;
          }else service.openToast(true,res.msg);
      })**/
    },
    //弹出框下注
    savePayBet(){

    },   
    //清空设置
    clearAll(){
        for(let i in this.lists.data){
            this.lists.data[i].check = false;
        }
        for(let i in this.lists.up){
              this.lists.up[i].check = false;
        }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

.bet-table-hexiao{
    border-top:1px solid #c6c6c6;

  ul{
    &.bet-table-hexiao-header{
      li{text-align: center; text-indent:0;   line-height:0.8rem;
        &:first-child{width:55%; text-align: center;}
        &::after{content: ""; border-right:1px solid #c6c6c6; float: right; height:0.8rem;}
        &:nth-child(4){ background: none;}
       }
    }
    border-bottom:1px solid #c6c6c6;
    li{ width:15%; float:left; text-align: center;  font-size:0.26rem;
      &:last-child::after{border-right:none; }
      &::after{content: ""; border-right:1px solid #c6c6c6; float: right; height:0.8rem;}
      &:nth-child(2),&:nth-child(3){line-height: 0.8rem;}
      &:nth-child(4){ background: url('../../assets/images/icon/checkbox.png') no-repeat center; background-size: 0.5rem; cursor: pointer;}
      &.active{ background: url('../../assets/images/icon/checkbox-active.png') no-repeat center; background-size: 0.5rem;}
      &:first-child{width:55%; text-align: left;
        span{background-color: #dd2638;  height:.45rem; margin: .18rem 0 0 .25rem; width:.45rem; line-height: .48rem; color:#fff; border-radius: 50%; display: inline-block; font-size:0.24rem; text-align: center;}
      }
    }
  }
}

.bet-w-3 {
  li{width:33.3%;}
}

</style>