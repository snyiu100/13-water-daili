<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" title="半波">
        <router-link to="/" slot="left" class="go-back"></router-link>  
        <span slot="right" class="cur"><router-link to="/rules">规则</router-link></span>
        </m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
         <bet-header></bet-header>
         <m-warp class="bgff">
              <div class="bet-table">
                <div class="bet-table-banbo bgff bet-table-no-chek">
                    <ul class="clearfix bet-table-banbo-header">
                      <li>号码</li>
                      <li>赔率</li>
                      <li>名称</li>
                      <li>金额</li>
                    </ul>
                    <ul class="clearfix" v-for="(vm,index) in lists.red_double" :key="index">
                      <li><span v-for="(arr,index) in vm.cate_num.split(',')" :key="index" :class="'bet-bg-'+vm.cate">{{arr}}</span></li>
                      <li>{{vm.Odds}}</li>
                      <li>{{vm.category}}</li>
                      <li><t-input v-model="vm.money"></t-input></li>
                    </ul>
                </div>
              </div> 
           </m-warp>
        </div>
      <bet-model v-model="isModel" @on-confirm="savePayBet" :info="betArr"></bet-model>
      <bet-footer></bet-footer>
  </div>

</template>

<script>
import {isBet} from "@/common/state"
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import {dates,shengXiaoDate,banBoData} from '@/common/bet'
import BetFooter from './betFooter'
import BetHeader from './betHeader'
import BetModel from './betModel'
import TInput from '@/components/t-input'
import service from '@/common/service'
export default {
  components:{
    MHeader,
    BetFooter,
    BetHeader,
    BetModel,
    TInput,
    MWarp
  },
  data () {
    return {
      isbet:isBet,
      lists:[],
      isModel:false,
      betArr:{bet:[],data:[]},
      info:{
        up:[{id:'',money:''}],
        down:[],
        betting_lx:[{type: 6,two_type: 0,three_type: 0,money: '0',fast:1}]
      }
    }
  },
  computed: {
    modelData(){
      let arr=[];
      for(let i in this.lists.red_double){
          if(this.lists.red_double[i].money!=''){
              arr.push(this.lists.red_double[i]);
          }
      }
      return arr;
    }
  },
  created(){   
    this.betShow();
  },
  methods:{
    //选择种类
    onOdd(vm){
      let index = this.lists.red_double.indexOf(vm);
      if(vm.check){
          this.lists.red_double[index].check = false;
      }else{
         this.lists.red_double[index].check = true;
      }
    },
    //获取数据 6：连半波
    betShow(){
      this.$http('bet/bet_show',{level:6}).then(res=>{
          if(res.code==200){
            for(let i in res.red_double){
              res.red_double[i].cate_num = banBoData[i];
              res.red_double[i].check = false;
              res.red_double[i].money = '';
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    //提交下注
    betSave(){
      //提交数据
      this.info.down =  shengXiaoDate(this.lists.red_double);
      if(this.info.down.length<1){
          service.openToast(true,"尚未输入金额");
          return false;
      } 
      service.betOrder(this.info).then(res=>{
          if(res.code==200){
              this.isModel = true;
              this.betArr = res;
              this.clearAll();
          }else service.openToast(true,res.msg);
      })
    },
    //弹出框下注
    savePayBet(){

    },
    //清空设置
    clearAll(){
        for(let i in this.lists.red_double){
            this.lists.red_double[i].check = false;
            this.lists.red_double[i].money = '';
        }
    },

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>


.bet-table-banbo{
    border-top:1px solid #c6c6c6;

  ul{
    &.bet-table-banbo-header{
      li{text-align: center; text-indent:0;   line-height:0.8rem;
  
        &:first-child{width:64%; text-align: center;}
        &::after{content: ""; border-right:1px solid #c6c6c6; float: right; height:0.8rem;}
        &:nth-child(4){ background: none;}
       }
    }
    border-bottom:1px solid #c6c6c6;
    li{ width:12%; float:left; text-align: center;  font-size:0.26rem;
      input{width:100%; height:100%; background-color: transparent; height:0.8rem; text-align: center; border:none; font-size:0.24rem;}
      &:last-child::after{border-right:none; }
      &::after{content: ""; border-right:1px solid #c6c6c6; float: right; height:0.8rem;}
      &:nth-child(2),&:nth-child(3){line-height: 0.8rem;}
      &:nth-child(4){ background: url('../../assets/images/icon/checkbox.png') no-repeat center; background-size: 0.5rem; cursor: pointer;}
      &.active{ background: url('../../assets/images/icon/checkbox-active.png') no-repeat center; background-size: 0.5rem;}
      &:first-child{width:64%; text-align: left;
        span{background-color: #dd2638;  height:.40rem; margin: .18rem 0 0 .06rem; width:.40rem; line-height: .40rem; color:#fff; border-radius: 50%; display: inline-block; font-size:0.22rem; text-align: center;}
      }
    }
  }
}

.bet-table-no-chek{
    ul{
        li{
          &:last-child{cursor: pointer; background: none;   background-size: .5rem; }
        }
    }     
}
</style>