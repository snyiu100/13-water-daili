<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" title="全不中"><router-link to="/" slot="left" class="go-back"></router-link><span slot="right" class="cur"><router-link to="/rules">规则</router-link></span></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
         <bet-header></bet-header>
         <m-warp class="bgff">
            <div class="bet-tez clearfix"><ul class="bet-tez-check"><li :class="vm.check?'active':''" v-for="(vm,index) in lists.up" @click="tezActive(vm)" :key="index" style="width:25%;">{{vm.category}}</li></ul></div>
            <div class="bet-table">
               <ul class="bet-table-h"><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li>金额</li></ul>
               <div class="bet-table-c bgff clearfix">
                  <ul v-for="(vm,index) in lists.data" :key="index">
                    <li><i :class="'bet-bg-'+vm.cate">{{vm.val}}</i></li>
                    <li>{{vm.Odds}}</li>
                    <li :class="vm.check?'active':''" @click="onOdd(vm)"></li>
                  </ul>
               </div>
            </div>
         </m-warp>
      </div>
      <bet-model v-model="isModel" :inputShow="false" :info="betArr"></bet-model>
      <bet-footer></bet-footer>
  </div>

</template>

<script>
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import BetFooter from './betFooter'
import BetHeader from './betHeader'
import service from '@/common/service'
import {shengXiaoCheckDate} from '@/common/bet'
import BetModel from './betModel'
export default {
  components:{
    MHeader,
    MWarp,
    BetFooter,
    BetHeader,
    BetModel
  },
  data () {
    return {
      lists:[],
      isModel:false,
      betArr:{bet:[],data:[]},
      info:{
        up:[],
        down:[{id:'',money:''}],
        betting_lx:[{type:11,two_type: 0,three_type: 0,money: '0',fast:2}]
      }
    }
  },
  created(){   
    this.betShow();
  },
  methods:{
     tezActive(vm){
      let index = this.lists.up.indexOf(vm);
      for(let i in this.lists.up){
        this.lists.up[i].check=false;
      }
      this.info.betting_lx[0].two_type = vm.id;
      this.lists.up[index].check=true;
    },

    //选择种类
    onOdd(vm){
      if(this.teMaState==1) return false;
      let index = this.lists.data.indexOf(vm);
      if(vm.check){
          this.lists.data[index].check = false;
      }else{
         this.lists.data[index].check = true;
      }
    },
    getThinking(betlsit){
        let two_type = this.info.betting_lx[0].two_type,flag = true;
        if(two_type==119 && betlsit.length!=5){
          service.openToast(true,"五不中请选择5位数");
          flag = false;
        }
        if(two_type==120 && betlsit.length!=6){
          service.openToast(true,"六不中请选择6位数");
          flag = false;
        }
        if(two_type==121 && betlsit.length!=7){
          service.openToast(true,"七不中请选择7位数");
          flag = false;
        }
        if(two_type==122 && betlsit.length!=8){
          service.openToast(true,"八不中请选择8位数");
          flag = false;
        }
        if(two_type==123 && betlsit.length!=9){
          service.openToast(true,"九不中请选择9位数");
          flag = false;
        }        
        if(two_type==124 && betlsit.length!=10){
          service.openToast(true,"十不中请选择10位数");
          flag = false;
        }
        if(two_type==125 && betlsit.length!=11){
          service.openToast(true,"十一不中请选择11位数");
          flag = false;
        }
        if(two_type==126 && betlsit.length!=12){
          service.openToast(true,"十二不中请选择12位数");
          flag = false;
        }
        return flag;
    },
   //获取数据  11:全不中
    betShow(){
      this.$http('bet/bet_show',{level:11}).then(res=>{
          if(res.code==200){
            for(let i in res.data){
              res.data[i].check = false;
            }
            for(let i in res.up){
              if(i==0){
                res.up[i].check=true;
                this.info.betting_lx[0].two_type = res.up[i].id;
              }else res.up[i].check = false;
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    //提交下注
    betSave(){
      this.info.up =  shengXiaoCheckDate(this.lists.data);
      if(this.info.up.length<1){
          service.openToast(true,"尚未选中");
          return false;
      } 
      console.log('11:全不中',this.info);
      if(this.getThinking(this.info.up)){
        service.betOrder(this.info).then(res=>{
            if(res.code==200){
                this.isModel = true;
                this.betArr = res;
            }else service.openToast(true,res.msg);
        })
      }
    },
    //清空设置
    clearAll(){
        for(let i in this.lists.data){
            this.lists.data[i].check = false;
        }
        for(let i in this.lists.up){
              this.lists.up[i].check = false;
        }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>




    .bet-table-h{ height:0.5rem; margin-top:0.1rem;
      li{ width:11.1%; font-size:.26rem; border-bottom:1px solid #c6c6c6; border-top:1px solid #c6c6c6; float: left; text-align: center; line-height: 0.5rem; position: relative; padding: 0.1rem 0;
        &:before{content: ""; border-right:1px solid #ddd; right:0; position: absolute; height: 100%; top:0;}
        &.bef:before{ border-color: #8e8e8e;}
        &:last-child{
          &:before{content: ""; border-right:none; }
        }
      }
    }

    .bet-table-c{
      text-align: center;
      ul{
        &.bef{
            li:last-child:before{ border-right: none;}
        }
        li{ position: relative; line-height: .5rem; width:11.1%; font-size:.26rem; border-bottom:1px solid #c6c6c6; height: .5rem; float: left; text-align: center; position: relative; padding: 0.1rem 0;
            i{height:.4rem; width:.4rem; color:#fff; border-radius: 50%; line-height: .4rem; background-color: #dd2638; display: inline-block;}
            &:before{content: ""; border-right:1px solid #ddd; right:0; position: absolute; height: 100%; top:0;}
            &:last-child{cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat center center;   background-size: .5rem; }
            &.active{ background: url('../../assets/images/icon/checked.png') no-repeat center center;   background-size: .5rem; }
            &:last-child:before{ border-color: #8e8e8e;}
        }
      }

    }

    .bet-footer{

      position: fixed; bottom: 1.18rem; width:100%;  
      display: flex;
      li{flex:1; text-align: center; font-size:.24rem; cursor: pointer; -webkit-box-shadow: 0px -3px 2px 0px #E7BFC3;;  box-shadow: 0px -3px 2px 0px #E7BFC3;; border-radius: 5px 5px 0 0;  height:.65rem; line-height: .6rem;  background: url('../../assets/images/icon/bet-f.jpg') repeat-x; background-size: contain;
        i{height:.28rem; width:.28rem; display: inline-block; vertical-align: sub; margin-right:.1rem;}
        &:last-child{background: url('../../assets/images/icon/bet-f-a.jpg') repeat-x; color:#fff;}
        &:nth-child(1) i{background: url('../../assets/images/icon/bet-footer-1.png') no-repeat; background-size: cover; }
        &:nth-child(2) i{background: url('../../assets/images/icon/bet-footer-2.png') no-repeat; background-size: cover; }
        &:nth-child(3) i{background: url('../../assets/images/icon/bet-footer-3.png') no-repeat; background-size: cover; }
      } 
    }

</style>