<template>
  <div>
    <bet-zou-shi v-model="zouShow"></bet-zou-shi>
    <bet-hot-and-cold v-model="coldShow" ></bet-hot-and-cold>
    <div class="bet-footer">
      <li @click="clearCheck()"><i></i>清空选项</li>
      <li @click="betFooter(1)" :class="zouShow?'active':''"><i></i>{{zouShow?'返回下注':'走势排行'}}</li>
      <li @click="betFooter(2)" :class="coldShow?'active':''"><i></i>{{coldShow?'返回下注':'冷热排行'}}</li>
      <li @click="onBetSave()">下注</li>
    </div>
    <td-confirm v-model="checkShow" @on-confirm="onConfirm">确认清空选项</td-confirm>
  </div>
</template>

<script>
import {isBet} from "@/common/state"
import BetHotAndCold from '@/components/betHotAndCold'
import BetZouShi from '@/components/betZouShi'
import TdConfirm from '@/components/confirm'
export default {
  components:{
    BetHotAndCold,
    BetZouShi,
    TdConfirm
  },
  data () {
    return {
      coldShow:false,
      zouShow:false,
      checkShow:false,
      isbet:isBet
    }
  },
  created(){   

  },
  methods:{
    betFooter(type){
      if(type==1){
        this.zouShow=!this.zouShow;
        this.coldShow=false;
      }else{
        this.coldShow=!this.coldShow;  
        this.zouShow=false;
      }
    },
    clearCheck(){
      this.checkShow=true;
    },
    //调用父组件方法
    onConfirm(){
       this.$parent.betShow();       
    },
    onBetSave(){
      this.zouShow=false;
      this.coldShow=false;
      this.$parent.betSave();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.bet-footer{width:100%;  z-index:770; display: flex; height:30px; position: fixed; bottom:0;
      li{flex:1; text-align: center; font-size:13px; cursor: pointer; -webkit-box-shadow: 0px -3px 2px 0px #E7BFC3;;  box-shadow: 0px -3px 2px 0px #E7BFC3; border-radius: 5px 5px 0 0;  height:30px; line-height:30px;  background: url('../../assets/images/icon/bet-f.jpg') repeat-x; background-size: contain;
        &.active{background: url('../../assets/images/icon/bet-f-a.jpg') repeat-x; color:#fff;}
        &.active:nth-child(2) i{background: url('../../assets/images/icon/bet-footer-2-a.png') no-repeat; background-size: cover; }
        &.active:nth-child(3) i{background: url('../../assets/images/icon/bet-footer-3-a.png') no-repeat; background-size: cover; }


        i{height:15px; width:15px; display: inline-block; vertical-align: sub; margin-right:.1rem;}
        &:last-child{background: url('../../assets/images/icon/bet-f-a.jpg') repeat-x; color:#fff;}
        &:nth-child(1) i{background: url('../../assets/images/icon/bet-footer-1.png') no-repeat; background-size: cover; }
        &:nth-child(2) i{background: url('../../assets/images/icon/bet-footer-2.png') no-repeat; background-size: cover; }
        &:nth-child(3) i{background: url('../../assets/images/icon/bet-footer-3.png') no-repeat; background-size: cover; }
      } 
}
@media (min-width: 320px) {
  .bet-footer li{font-size:12px;}
}
</style>