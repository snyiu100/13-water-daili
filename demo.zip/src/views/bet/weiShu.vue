<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" title="尾数"><router-link to="/" slot="left" class="go-back"></router-link><span slot="right" class="cur"><router-link to="/rules">规则</router-link></span></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
         <bet-header></bet-header>
         <m-warp class="bgff">
            <div class="weishu-c f24">
                <div class="weishu-cl">
                    <span>号码</span>
                    <span>赔率</span>
                    <span>金额</span>
                </div>
                <div class="weishu-cl">
                    <span>号码</span>
                    <span>赔率</span>
                    <span>金额</span>
                </div>
            </div>
            <div class="weishu-c f24 c666  clearfix">
                <div class="weishu-cl" v-for="(vm,index) in lists.data" :key="index">
                    <span>{{vm.category}}尾</span>
                    <span>{{vm.Odds}}</span>
                    <span><t-input v-model="vm.money"></t-input></span>
                </div>
            </div>
         </m-warp>
      </div>
      <bet-model v-model="isModel" @on-confirm="savePayBet" :info="betArr"></bet-model>
      <bet-footer></bet-footer>

  </div>

</template>

<script>
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import TInput from '@/components/t-input'
import {shengXiaoDate} from '@/common/bet'
import service from '@/common/service'
import BetFooter from './betFooter'
import BetHeader from './betHeader'
import BetModel from './betModel'
export default {
  components:{
    MHeader,
    MWarp,
    BetFooter,
    BetHeader,
    BetModel,
    TInput
  },
  data () {
    return {
      lists:[],
      isModel:false,
      betArr:{bet:[],data:[]},
      info:{
        up:[{id:'',money:''}],
        down:[],
        betting_lx:[{type: 12,two_type: 0,three_type: 0,money: '0',fast:1}]
      }
    }
  },
  created(){   
    this.betShow();
  },
  methods:{
    //获取数据  12:尾数
    betShow(){
      this.$http('bet/bet_show',{level:12}).then(res=>{
          if(res.code==200){
            for(let i in res.data){
              res.data[i].check = false;
              res.data[i].money = '';
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    //提交下注
    betSave(){
      this.info.down =  shengXiaoDate(this.lists.data);
      if(this.info.down.length<1){
          service.openToast(true,"尚未输入金额");
          return false;
      } 
      console.log("12:尾数",this.info);
      service.betOrder(this.info).then(res=>{
          if(res.code==200){
              for(let i in res.bet){
                res.bet[i].cate_num = res.bet[i].cate_num+'尾';
              }
              this.isModel = true;
              this.betArr = res;
              this.betShow();
          }else service.openToast(true,res.msg);
      })
    },
     //弹出框下注
    savePayBet(){

    },      
    //清空设置
    clearAll(){
        for(let i in this.lists.data){
            this.lists.data[i].check = false;
            this.lists.data[i].money = '';
        }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

    .bet-kj{
      position: relative; font-size:.28rem; padding: .25rem;
      ul{ position: absolute; right:.2rem; top:.25rem;
        li{height:0.4rem; width:0.4rem; float: left; margin-left:0.2rem; font-size:.2rem; border-radius: 50%; background-color:#dd2638; color:#fff; line-height: .4rem; text-align: center;
          &.jia{background-color: transparent; color:#333;margin-left:0px;}
        }
      }
    }
    .bet-tez{
        ul{
          display: flex; 
          li{flex:1;}
          &.bet-tez-check{
             li{cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat left center; font-size:.24rem; text-indent: .38rem; padding:.25rem 0px; background-size: .35rem;
              &.active{background: url('../../assets/images/icon/checked.png') no-repeat left center;  background-size: .35rem;}
            }
          }
        }
    }
  
    .bet-tez-checked{
      display: flex;
        div{  flex: 1;
           padding-left: 0.2rem;
          span{ cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat left center;   background-size: .45rem; padding-left:.5rem;
            &.active{
               background: url('../../assets/images/icon/checked.png') no-repeat left center;   background-size: .45rem; 
            }
          }
        }
    }
 .weishu-c{
     line-height: .76rem;
     background-color: #fff;
     span{text-align: center;}

     .weishu-cl{
        height:.76rem;
        width:50%;
        float:left;
        border-bottom:1px solid #c0c0c0;
        span{ width:33.3%; float:left; position: relative;
          &:before{border-right:1px solid #c0c0c0; content: "";position: absolute; height:100%; right:0;}
        }
        input{width:100%; height:100%; border:none; background-color: transparent; text-align: center}
    } 
    .weishu-cc{
        height:.76rem;
        width:.2rem;
        background-color:#efefef;
        border-bottom:1px solid #efefef;
    } 
    .weishu-cr{
        height:.76rem;
        flex:1;
        display:flex;
        border-bottom:1px solid #c0c0c0;
        span{border-left:1px solid #c0c0c0;};
        span:first-child{border-left:1px solid #8e8e8e;}
    } 
 }


    .bet-footer{

      position: fixed; bottom: 1.18rem; width:100%;  
      display: flex;
      li{flex:1; text-align: center; font-size:.24rem; cursor: pointer; -webkit-box-shadow: 0px -3px 2px 0px #E7BFC3;;  box-shadow: 0px -3px 2px 0px #E7BFC3;; border-radius: 5px 5px 0 0;  height:.65rem; line-height: .6rem;  background: url('../../assets/images/icon/bet-f.jpg') repeat-x; background-size: contain;
        i{height:.28rem; width:.28rem; display: inline-block; vertical-align: sub; margin-right:.1rem;}
        &:last-child{background: url('../../assets/images/icon/bet-f-a.jpg') repeat-x; color:#fff;}
        &:nth-child(1) i{background: url('../../assets/images/icon/bet-footer-1.png') no-repeat; background-size: cover; }
        &:nth-child(2) i{background: url('../../assets/images/icon/bet-footer-2.png') no-repeat; background-size: cover; }
        &:nth-child(3) i{background: url('../../assets/images/icon/bet-footer-3.png') no-repeat; background-size: cover; }
      } 
    }

</style>