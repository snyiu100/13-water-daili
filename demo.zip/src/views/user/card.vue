<template>
  <div class="td-warp">
      <m-header :showBack="true" title="银行卡"></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
        <div class="card-list pb10" v-for="(vm,index) in lists" :key="index">
            <div class="card-img">
                <img src="../../assets/images/home/zhaos.png" v-if="vm.bank=='建设银行'">
                <img src="../../assets/images/home/gongs.jpg" v-if="vm.bank=='工商银行'">
                <img src="../../assets/images/home/nongy.jpg" v-if="vm.bank=='农业银行'">
                {{vm.bank}}<p>{{vm.open_bank_city}}</p><span  @click="bangding(vm)" :class="vm.status==1?'active':''">{{vm.status==1?'默认':'绑定'}}</span>
            </div>
            <div class="pr20 mt10 text-right">{{vm.counter|cards}}</div>
        </div>
        <div class="card-save user-b mt30">
          <router-link to="/addCard"><i class="user-icon-5"></i>添加银行卡</router-link>
        </div>

      </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import service from '@/common/service'
export default {
  components:{
    MHeader
  },
  data(){
    return{
      lists:[]
    }
  },
  created(){
    this.showBankcard();
  },
  methods:{
    //获取银行卡全部信息
    showBankcard(){
       this.$http('center/showBankcard',{},true).then(data=>{
        if(data.code==200){
            this.lists = data.data;
        }else{
            service.openToast(true,data.msg);
        };
      })
    },
    //默认选中
    bangding(vm){
        if(vm.status==1){
          return false;
        }
        this.$http('center/bangding',{id:vm.id},true).then(data=>{
        if(data.code==200){
            this.showBankcard();
            service.openToast(true,"绑定成功");
        }else{
            service.openToast(true,data.msg);
        };
      })     
    }

  },
  filters:{
        cards(str){
            let start = str.slice(0,4);
            let end = str.slice(-4);
            return `${start}******${end}`;
        }
    }
}
</script>
<style lang="scss" scoped>
     .card-save{
        background-color: #fff;
            a{  line-height: 0.95rem; text-indent: 0.3rem; color:#404040; font-size:.3rem;background: url('../../assets/images/icon/right.png') no-repeat 98% center; background-size: 0.5rem;
            i{height:.44rem; width:.44rem; display: inline-block; vertical-align: middle; margin-right: 0.1rem;}
        }
     }
   .card-list{text-align: left; position: relative; padding-left: 0.2rem; display: block; margin:.1rem; padding-top:.2rem; border-radius: 5px; color:#333; background-color:#fff; font-size:.4rem;
       .card-img{ position: relative; font-size:.29rem; padding-left: .9rem; color:#333;
          p{font-size:.26rem; color:#999; line-height: .4rem;}
          img{height:.7rem; width:.7rem; position: absolute; left:0;}
          span{position: absolute; right: 0.2rem; top:0; padding:.08rem .1rem; font-size:0.24rem; color:#999; border-radius: 2px; border:1px solid #999;
            &.active{color:#00af27; border-color:#00af27;}
          }
       }
       
      
   }
</style>