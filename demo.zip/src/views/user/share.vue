<template>
  <div class="td-warp">
      <m-header :showBack="true" title="分享"></m-header>
      <div>
        <div class="text-center" style="padding-top:50%; padding-bottom:1.5rem;">
          <qrcode :value="valCode" type="img" size="80"></qrcode>
        </div>
        <div class="btn mt50 br3 cur" style="margin:0 1rem;" @click="ishare=!ishare">分     享</div>
      </div>
      <t-dshare v-model="ishare" :info="info"></t-dshare>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import TDtabs from '@/components/tabs'
import TDshare from '@/components/share'
import Qrcode from '@/components/qrcode'
export default {
  components:{
    MHeader,
    TDtabs,
    TDshare,
    Qrcode
  },
  data () {
    return {
        valCode:'http://www.tiandingkeji.com/',
        ishare:false,
        info:{}
    }
  },
  created(){   
    this.onshare();
  },
  methods:{
     onshare(){
        this.$http('share/shares',{},true).then(data=>{
            this.info = data.data[0];
            this.valCode = data.data[0].url;
        })
     }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
  .winning-list{ 
    li{border-bottom:1px solid #c6c6c6; background-color: #fff; padding:.15rem;  clear: both;
      .title{font-size:0.3rem; color:#333;
        span{color:#666666; font-size:.26rem; padding-left:.2rem;}
      }
      .winn-date{
        display: flex; padding-top:0.2rem; color:#666666;
        div{
          &.c3{color:#333;
              span{padding-left:31%;}
          }
          &:first-child{flex:7}
          &:last-child{flex:3}
        }
      }
     }
  }
</style>
