<template>
  <div class="td-warp">
      <m-header :showBack="true" title="添加银行卡"></m-header>
       <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
        <div class="user-eidt mt15">
            <div><label class="text-center">卡号</label><input type="text" v-model="info.counter" placeholder="请输入银行卡号" /></div>
        </div>
        <div class="user-eidt mt15">
            <div><label class="text-center">姓名</label><input type="text" v-model="info.true_name" placeholder="请输入姓名" /></div>
            <div><label class="text-center">开户银行</label><select v-model="info.bank"><option value="建设银行">建设银行</option><option value="工商银行">工商银行</option><option value="农业银行">农业银行</option><option value="招商银行">招商银行</option></select></div>
            <div><label class="text-center">开户城市</label><input type="text" v-model="info.open_bank_city" placeholder="请输入开户城市" /></div>
        </div>
        <div class="btn ml20 mt20 mr20 br3 cur" @click="addBank()">保存信息</div>
      </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import service from '@/common/service'
export default {
  components:{
    MHeader
  },
  data () {
    return {
      info:{}
    }
  },
  methods:{
      addBank(){
          var num = /^\d*$/; //全数字
          if(!this.info.counter){
            service.openToast(true,"卡号为空");
            return false
          }

          if(!num.exec(this.info.counter)) {
            service.openToast(true,"卡号必须全为数字");
            return false;
          }

          //开头6位
          var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
          if(strBin.indexOf(this.info.counter.substring(0, 2)) == -1) {
             service.openToast(true,"卡号开头6位不符合规范");
             return false;
          }

          if(this.info.counter.length < 16 || this.info.counter.length > 19) {
             service.openToast(true,"卡号长度必须在16到19之间");
             return false;
          }

          if(!this.info.true_name){
             service.openToast(true,"姓名不为空");
             return false;
          }

          if(!this.info.bank){
             service.openToast(true,"开户银行不为空");
             return false;
          }

          if(!this.info.bank){
             service.openToast(true,"开户银行不为空");
             return false;
          }

          this.$http('center/addBank',this.info,true).then(data=>{
            if(data.code==200){
                this.$router.push({ path: '/userCard' });	
                service.openToast(true,"提交成功");
            }else if(data.code==-11){
                this.$router.push({ path: '/ptPassword' });	
                service.openToast(true,"请设置支付密码");
            }else{
                service.openToast(true,data.msg);
            };
          })
      }
  },
  filters:{
        cards(str){
            let start = str.slice(0,4);
            let end = str.slice(-4);
            return `${start}******${end}`;
        }
    }
}
</script>
<style lang="scss" scoped>
  .user-eidt{
    background-color: #fff;
    div{ width:100%; display: flex; border-bottom:1px solid #ddd; padding:0.3rem 0;
       label{ flex: 2; font-size:.28rem;}
       input,select{border:none; flex: 8; margin-right: .1rem; font-size:.26rem; background-color: transparent;}
    }
  }
</style>