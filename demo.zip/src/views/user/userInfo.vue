<template>
  <div class="td-warp bgef">
      <m-header :showBack="true" title="我的"></m-header>
       <div class="tb-content-warp"  :class="isIos?'iosMarginTop':''">
        <div class="user-header bgff">
              <div class="user-file"><img :src="info.avatar"><input  class="file" name="file" type="file" accept="image/png,image/gif,image/jpeg" @change="updateAvatar" multiple /></div>
        </div>
        <div class="user-eidt mt15">
            <div><label class="text-center">昵称</label><input type="text" v-model="info.user_name" placeholder="请输入昵称" /></div>
            <div><label class="text-center">性别</label><select v-model="info.sex"><option :value="0">保密</option><option :value="1">女</option><option :value="2">男</option></select></div>
        </div>
        <div class="btn ml20 mt20 mr20 br3 cur" @click="updateUserInfo()">保存信息</div>
      </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import service from '@/common/service'
import storage from '@/common/localStorage'
export default {
  components:{
    MHeader
  },
  data () {
    return {
      info:{}
    }
  },
  created(){   
    this.userInfo();
  },
  methods:{
      //获取用户信息
      userInfo(){
        this.$http('center/check_user_data',{},true).then(data=>{
            this.info = data.data[0];
        })
      },
      //修改用户信息
      updateUserInfo(){
        this.$http('center/upd_user_data',this.info).then(data=>{
            if(data.code==200){
                service.openToast(true,"修改成功");
                this.userInfo()
            }else service.openToast(true,data.msg);
        })
      },
      //修改头像
      updateAvatar(e){

            let uid = storage.getItem('user_id');
            let file = e.target.files[0];           
            let formdata = new FormData(); //创建form对象        
            formdata.append("file", file ,"file_"+(new Date()).valueOf()+".jpg");  
            formdata.append("user_id", uid);   
            const xhr = new XMLHttpRequest()
                 xhr.open('POST', "http://cai.test.jxcraft.net:40201/TP5/public/index.php/admin/center/upd_user_data", true)
                 xhr.send(formdata)
                 xhr.onload = () => {
                    if (xhr.status === 200) {
                        service.openToast(true,'上传头像成功');
                        this.userInfo();
                    } else {
                        console.log(`error：error code ${xhr.status}`)
                        service.openToast(true,'上传头像失败');
                    }
            }
        }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
  .user-header{ border-bottom:1px solid #c6c6c6;  padding:.3rem; text-align: center;
      .user-file{ height: 1.6rem; width: 1.6rem; display: inline; position: relative;
        input{ opacity: 0;height: 1.6rem; width: 1.6rem; position: absolute; left: 0;}
        img{ border-radius: 50%; vertical-align: sub; height: 1.6rem; width: 1.6rem; }
      }
  }

  .user-eidt{
    background-color: #fff;
    div{ width:100%; display: flex; border-bottom:1px solid #ddd; padding:0.3rem 0;
       label{ flex: 2; font-size:.28rem;}
       input,select{border:none; flex: 8; margin-right: .1rem; font-size:.26rem; background-color: transparent;}
    }
  }
</style>
