
<template>
  <div style="height:100%">
       <m-header :showBack="true" title="设置登录密码"></m-header>
       <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
          <div class="regFrom">
                <input type="password" class="reg_pa" placeholder="请设置登录密码" v-model="info.passwordOne" />
                <input type="password" class="reg_pa" placeholder="再次输入登录密码" v-model="info.password" />
                <input type="button" value="提交"  class="regButton" @click="login_pwd" />
          </div>
       </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import localStorage from '@/common/localStorage'
import TdToast from '@/components/toast'
import service from '@/common/service'

export default {
  components:{
    MHeader,
    TdToast,
  },
  data () {
    return {
      info:{}
    }
  },
  methods:{

      login_pwd() {//设置登录密码
      if(!this.info.passwordOne && !this.info.password){
        service.openToast(true,"密码不能为空");
        return false;
      }

      if(this.info.passwordOne != this.info.password){
        service.openToast(true,"两次密码输入不一致");
        return false;
      }

      this.$http('center/login_pwd',{pwd:this.info.password},true).then(data=>{
        if(data.code==200){
          service.openToast(true,"设置成功");
          this.$router.push({ path: '/' });
        }else{
          service.openToast(true,data.msg);
        };
      })
		}
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
div{background-color:#fff;}
.regFrom{padding:0 1rem;margin:1rem auto 0;}
  .reg_pa{font-size: .28rem;line-height: .28rem;padding:.20rem 0;background-color: #fff;border: 2px solid #ec504c;border-radius: 5px;width:99%;text-indent: .8rem;margin-bottom:.8rem;}
  .regButton{
	padding: .2rem;
	width: 100%;
	border-radius: 5px;
	background: -webkit-linear-gradient(left, #de2839 , #fe8263); /* Safari 5.1 - 6.0 */
    background: -o-linear-gradient(right, #de2839, #fe8263); /* Opera 11.1 - 12.0 */
    background: -moz-linear-gradient(right, #de2839, #fe8263); /* Firefox 3.6 - 15 */
    background: linear-gradient(to right, #de2839 , #fe8263); /* 标准的语法（必须放在最后） */
  color:#fff;}
	.btn_code{width: 30.9%; padding: .22rem 0; border-left: none; border-radius: 0 5px 5px 0; text-indent: 0rem;}
</style>
