<template>
 <div class="indexbox" style="width: 100%;">
			<div class="indexbox">
				<div class="indexbox200">
					<div class="index_nav">
						<div class="clickaddnavbox">
							<div class="index_home" @click="$router.push('/home')">
								<img src="../assets/img/u98.png" /> 代理后台
							</div>
							<div class="clickaddnav">
								><span>道具赠送</span>
							</div>
						</div>
					</div>
					<div class="gift_form_box">
						<div class="gift_type">
							<span class="must">*</span>
							<span class="gift_type_title">道具类型</span>
							<input type="radio" name="golddemond" id="demond" value="demond" v-model="info.goods_type"/><label for="demond">钻石</label>
							<input type="radio" name="golddemond" id="gold" value="gold" v-model="info.goods_type"/><label for="gold">金豆</label>
							<div class="clear"></div>
						</div>
						<div class="gift_type use_type">
							<span class="must">*</span>
							<span class="gift_type_title">操作类型</span>
							<input type="radio" name="people_type" id="gamer" value="toPlayer" v-model="info.action_type"/><label for="gamer">赠送给玩家</label>
							<input type="radio" name="people_type" id="agent" value="toAgent" v-model="info.action_type"/><label for="agent">赠送给代理</label>
							<div class="clear"></div>
						</div>
						<div class="gift_type game_id" style="position: relative;">
							<span class="must">*</span>
							<span class="gift_type_title" style="height: 1rem;">游戏ID</span>
							<input type="text" name="" id="clickchoosegameid" value="" placeholder="请输入游戏ID" @click="status=!status" @blur="verification" v-model="info.user_id"/>
							<!-- <img src="../assets/img/u56.png" class="positionimg" /> -->
							<div class="clear"></div>
						</div>
						<div class="nowdaysidbox">
							<div class="nowdaysid" :style="status?'display:block':''">
								<p>最常使用</p>
								<!-- <img src="../assets/img/u309.png" @click="status=!status"/> -->
								<ul class="nowdaysidul">
									<li>111111</li>
								</ul>
								<div class="clear"></div>
							</div>
						</div>
						<div class="gift_type game_id ganernamer" style="border: 0;">
							<span class="gift_type_title" style="color: #333333 !important;font-size: 0.3rem;">玩家昵称</span>
							<input type="text" name="" id="idgamername" value="" readonly="readonly" v-model="nick_name"/>
							<div class="clear"></div>
						</div>
						<div class="" style="border-top: 4px solid #e4e4e4;">
							<div class="gift_type game_id ganernamer">
								<span class="gift_type_title nowroomcard">当前道具数量</span>
								<span style="margin-left: 0.5rem;">0</span>
								<div class="clear"></div>
							</div>
							<div class="gift_type game_id" style="position: relative;">
								<span class="must">*</span>
								<span class="gift_type_title" style="height: 1rem;">赠送数量</span>
								<input type="text" name="" id="sendmathnum" value="" placeholder="请输入赠送数量" />
								<!-- <img src="../assets/img/u56.png" class="positionimg" /> -->
								<div class="clear"></div>
							</div>
							<div class="gift_type game_id" style="border: 0;">
								<span class="gift_type_title" style="height: 1rem;margin-left: 0.15rem;">快捷赠送</span>
								<ul class="fastgift">
									<li>
										<div class="xiahuaxian">20</div>
									</li>
									<li>
										<div class="xiahuaxian">20</div>
									</li>
									<li>
										<div class="xiahuaxian">20</div>
									</li>
									<li>
										<div class="xiahuaxian">20</div>
									</li>
								</ul>
								<div class="clear"></div>
							</div>
						</div>
					</div>
					<div class="nowwaycengbtn">
						立即赠送
					</div>
				</div>
			</div>
		</div>
</template>
<script>
export default {
  data() {
    return {
      info: {
        method: ""
      },
      status: false,
      nick_name: ""
    };
  },
  created() {
    this.initUsual();
  },
  methods: {
    initUsual() {
      this.$http({}, { method: "getRecentlyUserInfo" }).then(data => {
        console.log(data);
      });
    },
    verification() {
      this.$http(
        {},
        { method: "checkUserId", user_id: this.info.user_id }
      ).then(data => {
        console.log(data);
        if (data.Code == 0) {
          if (this.info.user_id != "") {
            nick_name = data.Data.nick_name;
          }
        } else {
          this.toast(data.Data.msg);
        }
      });
    }
  }
};
</script>

