<template>
  <div class="td-warp">
      <m-header :showBack="true" title="存取款"></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
        <div class="pt30 pb20 bgff mb20 pl30 pr20 f30">当前余额<p class="f56 pt30 pb30">{{uInfo.money||0.00}}</p></div>
        <td-tabs :lists="tabs" v-model="istab"></td-tabs>
        <div class="bgff pb50" v-if="istab==0">
          <div class="ml15 mr15 b-b-cf0f text-center pt20 pb20 c333">上线充值方式</div>
          <div class="accessMoney" style="margin-bottom:0px;">
              <input type="number" v-model="accessMoney" placeholder="请输入金额"/>元
          </div>
          <ul class="accessMon pt20 text-center pb20">
            <li v-for="(vm,$index) in chongz" :key="$index" @click="onChongz(vm)" :class="vm.checked?'active':''">{{vm.name}}</li>
          </ul>
          <div class="btn ml80 mr80 br3 cur mt20" @click="payMoney()">去充值</div>
        </div>
        <div class="bgff pb50 pt10" v-if="istab==1">
            <div class="accessMon-tx">
              <ul><li>&nbsp;提现账户</li><li>{{carry.counter}}</li></ul>
              <ul><li>&nbsp;所属银行</li><li>{{carry.bank}}</li></ul>
              <ul><li>&nbsp;开户行城市</li><li>{{carry.open_bank_city}}</li></ul>
              <ul><li>&nbsp;账号姓名</li><li>{{carry.true_name}}</li></ul>
              <ul><li>&nbsp;提现金额</li><li><input type="text" placeholder="输入提现金额" v-model="savaPay.money"></li></ul>
              <ul><li>&nbsp;提款密码</li><li><input type="password" placeholder="输入提现密码" v-model="savaPay.carry_money_pwd"></li></ul>
              <ul><li>&nbsp;当前可提现金额为</li><li class="cdd2">￥{{uInfo.money||0.00}}</li></ul>
            </div>
            <div class="btn ml80 mr80 br3 cur mt40" @click="carryMoneyButton()">提现</div>
        </div>
      </div>
      <td-confirm v-model="isMore" confirm-text="去绑定" @on-confirm="bindConfirm()">暂无绑定提现银行卡，请绑定。</td-confirm>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import TdTabs from '@/components/tabs'
import TdConfirm from '@/components/confirm'
import service from '@/common/service'
import storage from '@/common/localStorage'
import Sdk from '@/common/sdk'

export default {
    components:{
      MHeader,
      TdTabs,
      TdConfirm
    },
    data () {
      return {
          tabs:['充值','提现'],
          isMore:false,
          accessMoney:'',
          chongz:[{id:1,name:'支付宝',checked:true},{id:1,name:'银行卡',checked:false}],
          payInfo:{WIDsubject:'充值',WIDtotal_amount:0,user_id:storage.getItem('user_id')},
          istab:0,
          lists:[],
          uInfo:{},  //用户信息
          savaPay:{},
          carry:{},  //银行卡信息
      }
    },
    created(){
      this.istab = parseInt(this.$route.params.id)-1;
      this.userInfo();
    },
    watch:{
      istab(val){
          if(val==1){
             this.carryMoneyPage();
          }
      }
    },
    methods:{
      //获取用户信息
      userInfo(){
        this.$http('center/check_user_data',{},true).then(data=>{
          this.uInfo = data.data[0];
        })
      },
      payMoney(){
        if(this.accessMoney==0 || this.accessMoney==''){
            service.openToast(true,'充值金额不能为空');
            return false;
        }
        let that = this;
        this.payInfo.WIDtotal_amount = this.accessMoney;
        this.$http('payment/alipay',this.payInfo).then(data=>{
            if(data.code==200){
              Sdk.AliPay.login(data.data[0].longstring,function (response) {
                if(response.resultStatus==9000){
                    that.accessMoney='';
                    that.userInfo();
                }
                //var obj = JSON.stringify(response);
                //alert(obj);
              }, function (reason) {
                //alert("authFailed: " + JSON.stringify(reason));
              });
            }else service.openToast(true,res.msg);
             
        })  

      },
      //获取提现银行卡
      carryMoneyPage(){
          this.$http('center/carry_money_page',{},true).then(data=>{
              if(data.code==200){
                this.carry = data.data[0];
              }else if(data.code==-11){
                this.isMore=true;
              }else {
                service.openToast(true,res.msg);
              }
     
          })      
      },
      //提现
      carryMoneyButton(){
        if(!this.savaPay.money && !this.savaPay.carry_money_pwd){
          service.openToast(true,'金额或提现密码不能为空');
          return false;
        }

        let user = {
                carry_money_way:this.carry.carry_money_way,
                bank:this.carry.bank,
                open_bank_city:this.carry.open_bank_city,
                counter:this.carry.counter,
                true_name:this.carry.true_name,
                money:this.savaPay.money,
                carry_money_pwd:this.savaPay.carry_money_pwd
         };

        this.$http('center/carry_money_button',user,true).then(res=>{
          if(res.code==200){
              this.carryMoneyPage();
              this.savaPay.money = '';
              this.savaPay.carry_money_pwd = '';
              service.openToast(true,'申请提现成功？');
          }else service.openToast(true,res.msg);
     
        })   
      },
      onChongz(vm){
          for(var i in this.chongz){
              if(vm==this.chongz[i]){
                  this.chongz[i].checked=true;
              }else{
                  this.chongz[i].checked=false;
              }
          }
      },
      bindConfirm(){
         this.$router.push({ path: '/userCard' });	
      } 
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.accessMon{ width:40%; margin:0px auto;
    li{ background: url('../../assets/images/icon/check.png') no-repeat left center; cursor: pointer; background-size: 0.5rem; line-height: 0.6rem; font-size:0.28rem; color:#666666;
    &.active{ background: url('../../assets/images/icon/checked.png') no-repeat left center; background-size: 0.5rem;}
    }
}

.accessMon-tx{border:1px solid #ddd; margin:0.2rem; border-radius: 3px; -webkit-box-shadow: 0px 0px 5px #ddd; box-shadow: 0px 0px 5px #ddd;
  ul{border-bottom:1px solid #ddd; display: flex;
    li{flex: 2; font-size:0.3rem; text-indent: 0.1rem; padding:0.2rem 0; color:#999;
    input[type="text"],input[type="password"]{background: transparent; border:none; width:80%; font-size:0.3rem}
      &:nth-child(2){color:#999999}
    }
  }
}

.accessMoney{
    font-size:0.26rem;
    color:#666666;
    padding:0 0.2rem;
    width:60%;
    line-height: 0.6rem;
    margin:0.5rem auto;
    border-radius: 5px;
    background-color: #efefef;
      input{ 
        border:none;
        width:90%;
        font-size:0.26rem;
        background-color: transparent;

      }
  
   }



</style>
