<template>
  <div class="td-warp">
        <m-header title="首页" :showBack="false"></m-header>
        <div class="tb-content-warp" style="padding-bottom:1.15rem;" :class="isIos?'iosMarginTop':''">
          <swiper :options="swiperOption"  ref="mySwiper"> 
              <!-- 这部分放你要渲染的那些内容 -->  
              <swiper-slide  v-for="(str,index) in datas.banner" :key="index" >
                <img :src="str.banner" />  
              </swiper-slide>  
              <!-- 这是轮播的小圆点 -->  
              <div class="swiper-pagination" slot="pagination"></div>  
          </swiper>  
          <div class="menu">
            <router-link to="/accessMoney/1"><img src="../../assets/images/home/menu-1.png"><p>存取款</p></router-link>
            <router-link to="/news"><img src="../../assets/images/home/menu-2.png"><p>资讯</p></router-link>
            <router-link to="/hZoushi"><img src="../../assets/images/home/menu-3.png"><p>走势</p></router-link>
            <router-link to="/problem"><img src="../../assets/images/home/menu-4.png"><p>常见问题</p></router-link>
          </div>
          <div class="home-gg">
              <ul :style="{ top }">
                <li v-for="(messgae,index) in datas.system_message" :key="index">{{messgae.content}}</li>
              </ul>
          </div>
          <div class="bgff mt15">
            <div class="ml20 mr20 h-tile"><span>彩种</span></div>
            <ul class="home-czhong">
                <li class="liuhc"><router-link to="/betTeMa/1">香港六合彩<p>六合彩</p></router-link></li>
                <li class="more" @click="isMore=true"><a href="javascript:void(0)">更多<p>更多</p></a></li>
            </ul>
          </div>
          <div class="bgff mt15">
            <div class="ml20 mr20 h-tile"><span>最新中奖</span></div>
            <ul class="home-list">
                <li v-for="(vm,$index) in datas.data" :key="$index">恭喜 {{vm.user_name}}： 我要发大财 【六合彩】中奖{{vm.money}}元</li>
            </ul>
            <!--div class="f24 mt20 pb20 text-center">暂无数据</div-->
          </div>
        </div>
        <td-confirm v-model="isMore">更多精彩，敬请期待</td-confirm>
  </div>
</template>

<script>
import { swiper, swiperSlide } from 'vue-awesome-swiper' 
import MHeader from '@/components/header'
import Marquee from '@/components/marquee'
import TdConfirm from '@/components/confirm'
import service from '@/common/service'
import storage from '@/common/localStorage'
export default {
  components:{
    MHeader, 
    Marquee,
    TdConfirm
  },
  data () {
    return {
      isMore:false,
      show:false,
      datas:{},
      activeIndex:0,
      swiperOption: {  
          //是一个组件自有属性，如果notNextTick设置为true，组件则不会通过NextTick来实例化swiper，也就意味着你可以在第一时间获取到swiper对象，假如你需要刚加载遍使用获取swiper对象来做什么事，那么这个属性一定要是true  
          notNextTick: true,  
          roundLengths:true,
          pagination: '.swiper-pagination',  
          autoplayDisableOnInteraction:false,
          onSlideChangeEnd: swiper => {  
              //这个位置放swiper的回调方法  
              this.page = swiper.realIndex+1;  
              this.index = swiper.realIndex;  
            }  
          } 
      }
  },
 computed: {
    top() {
      return - this.activeIndex * 32 + 'px';
    }
  },
  swiper() {  
    return this.$refs.mySwiper.swiper;  
  },
  mounted() {
     //this.swiper.slideTo(3, 1000, false)
    //首页轮播
    if(JSON.stringify(this.datas.system_message)!=='[]'){
      setInterval(_ => {
        if(this.activeIndex < this.datas.system_message.length) {
          this.activeIndex += 1;
        } else {
          this.activeIndex = 0;
        }
      }, 1000);
    }


  },
  created(){
    this.homeIndex();
  },
  methods:{
    //根据定位信息（市）选择店铺页面
    homeIndex(){
      this.$http('home/index',{}).then(data=>{
            if(data.code==200){
               storage.setItem('news',data.img);
               this.datas = data;
            }
        })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scope>
$c333:#333;
$cfff:#fff;
.banner{height:3.48rem; overflow: hidden;
   img{width:100%;}
}
.swiper-container{width:100%;  height:2.5rem;position: relative; overflow: hidden; z-index: 1;
  .swiper-wrapper{ position: relative; width: 100%; height: 100%; z-index: 1; display: -webkit-box; display: -moz-box;  display: -ms-flexbox;  display: -webkit-flex; display: flex; -webkit-transition-property: -webkit-transform; -moz-transition-property: -moz-transform; -o-transition-property: -o-transform;  -ms-transition-property: -ms-transform;  transition-property: transform; -webkit-box-sizing: content-box; -moz-box-sizing: content-box; box-sizing: content-box;

    .swiper-slide{ width:100%; text-align: center; font-size: 18px;  display: -webkit-box; display: -ms-flexbox;  display: -webkit-flex;  display: flex; -webkit-box-pack: center; -ms-flex-pack: center;  -webkit-justify-content: center; justify-content: center;  -webkit-box-align: center;  -ms-flex-align: center; -webkit-align-items: center;  align-items: center;
         img{width:100%;}
    } 
  }
  .swiper-pagination{ position: absolute; bottom:10px; width:100%; text-align: center;
    span{height:10px; width:10px; background-color: #f98b96; border-radius: 50%; display: inline-block; margin:0px 8px;
      &.swiper-pagination-bullet-active{ background-color: #dd2638}
    }
   }
}


.menu{ margin:0.2rem; background-color: #fff; border-radius: 5px; display: flex; display: -webkit-flex; text-align: center; padding:0.2rem 0;
    box-shadow: 0px 3px 10px #C5C5C5;
    a{flex: 1; font-size:0.28rem; color:$c333;
      img{height:1.2rem; width:1.2rem; border:none;}
    }
 }
 .h-tile{ padding:0.17rem 0; border-bottom:1px solid #eee; margin-left:0.2rem;
  span{border-left:3px solid #dd2638; font-size:.28rem; color:$c333;padding-left: 5px;}
 }
.home-czhong{
  display: flex;
  li{ flex: 1; margin-left:0.48rem; height:1.5rem;  padding-top:0.35rem; font-size:0.3rem;
    a{color:#333;}
    @each $val in liuhc,more{
        &.#{$val}{background:url('./../../assets/images/home/#{$val}.png') no-repeat left center; background-size: 1.35rem; padding-left: 1.50rem;}
    }
    p{color:#7a7a7a; font-size:0.24rem; padding-top: 0.1rem;}
  }
}

.home-list{
    padding:.1rem 0;
   li{color:#fd7f62; font-size:.24rem; text-indent: 0.3rem; padding: .1rem 0;
    &:last-child{ color:#999999}
   }
}
 .home-gg{height:0.78rem; overflow: hidden; line-height: 0.78rem; border-bottom:1px solid #c6c6c6; background: url('../../assets/images/home/gg.png') #fff no-repeat 0.2rem center; padding-left: 0.8rem; background-size: 0.47rem;
    ul{ position: relative; transition: top 0.5s;}

  }
</style>
