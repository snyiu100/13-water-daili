<template>
  <div class="td-warp">
        <m-header :showBack="true" title="走势"></m-header>
       <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
        <div class="bgff pb10 pt20">
            <div class="h-tile mr20"><span>号码</span></div>
            <table class="zoushi-table">
              <tr>
                <th class="text-left  pl15">期数</th>
                <th>正码1</th>
                <th>正码2</th>
                <th>正码3</th>
                <th>正码4</th>
                <th>正码5</th>
                <th>正码6</th>
                <th>特码</th>
              </tr>
              <tr v-for="(vm,$index) in datas.data" :key="$index">
                <td class="text-left pl15">{{vm.award_date||'无'}}</td>
                <td>{{vm.one}}</td>
                <td>{{vm.two}}</td>
                <td>{{vm.three}}</td>
                <td>{{vm.four}}</td>
                <td>{{vm.five}}</td>
                <td>{{vm.six}}</td>
                <td>{{vm.seven}}</td>
              </tr>
            </table>
        </div>
        <div class="bgff mt15 pb10">
            <div class="h-tile mr20"><span>混合</span></div>
            <table class="zoushi-table">
              <tr>
                <th class="text-left pl15">期数</th>
                <th>总和</th>
                <th>大小</th>
                <th>单双</th>
                <th>色波</th>
              </tr>
              <tr v-for="(vm,$index) in datas.mix" :key="$index">
                <td class="text-left pl15">{{vm.award_date||'无'}}</td>
                <td>{{vm.z_sum||'无'}}</td>
                <td>{{vm.big_small||'无'}}</td>
                <td>{{vm.single_doubles||'无'}}</td>
                <td>{{vm.colors||'无'}}</td>
              </tr>
            </table>
        
        </div>
        <div class="bgff mt15 pb10">
            <div class="h-tile mr20"><span>生肖</span></div>
            <table class="zoushi-table">
              <tr>
                <th class="text-left pl15">期数</th>
                <th>正码1</th>
                <th>正码2</th>
                <th>正码3</th>
                <th>正码4</th>
                <th>正码5</th>
                <th>正码6</th>
                <th>特码</th>
              </tr>
              <tr v-for="(vm,$index) in datas.zodiac" :key="$index">
                <td class="text-left pl15">{{vm.award_date||'无'}}</td>
                <td>{{vm.zodiac_one||'无'}}</td>
                <td>{{vm.zodiac_two||'无'}}</td>
                <td>{{vm.zodiac_three||'无'}}</td>
                <td>{{vm.zodiac_four||'无'}}</td>
                <td>{{vm.zodiac_five||'无'}}</td>
                <td>{{vm.zodiac_six||'无'}}</td>
                <td>{{vm.zodiac_seven||'无'}}</td>
              </tr>
            </table>
        </div>
        </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
export default {
  components:{
    MHeader,
  },
  data () {
    return {
      datas:{},
    }
  },
  created(){   
    this.awardDateTrend();
  },
  methods:{
       awardDateTrend(){
         this.$http('award/date_trend',{}).then(res=>{
            this.datas = res;
         })
       }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

 .zoushi-table{ width:100%; margin:.2rem 0; text-align: center;
    th{font-size:.26rem; line-height: 0.5rem; font-weight: normal;}
    td{font-size:.26rem; line-height: 0.5rem;}
}

</style>
