
<template>
  <div class="td-warp">
    <div class="index_nav">
			<div class="clickaddnavbox">
				<div class="index_home" @click="$router.push('/home')">
					<img src="../assets/img/u98.png" style="width: 0.5rem;" /> 代理后台
				</div>
				<div class="clickaddnav createlevel2">
					><span>修改密码</span>
				</div>
			</div>
		</div>
       <div class="mymsg">
			<div class="myzhanghao">
				登录密码(为空表示不修改)
			</div>
			<div class="agent_edit_base">
				<div class="agent_flo agent_flop">
					<p>原密码</p>
					<input type="password" placeholder="请输入原密码" value="" v-model="info.old_password"/>
				</div>
			</div>
			<div class="agent_edit_base">
				<div class="agent_flo agent_flop">
					<p>新密码</p>
					<input type="password" placeholder="请输入新密码" value="" v-model="info.new_password"/>
				</div>
			</div>
			<div class="agent_edit_base">
				<div class="agent_flo agent_flop">
					<p>确认密码</p>
					<input type="password" placeholder="确认新密码" value="" v-model="info.asure_password"/>
				</div>
			</div>	
		</div>
		<div class="nowwaycengbtn" style="margin-top: 5rem;" @click="passChange">
			提交
		</div>
  </div>
</template>

<script>
import storage from '@/common/localStorage'
export default {
  data() {
    return {
      info: {
        method: "editPassword"
      }
    };
  },
  created() {},
  methods: {
    passChange() {
      if (this.info.old_password != storage.getItem("agent_password")) {
        this.toast("原密码不正确");
      } else if (this.info.new_password != this.info.asure_password) {
        this.toast("两次新密码不一致");
      } else {
        this.$http(
          {},
          {
            method: this.info.method,
            old_password: this.info.old_password,
            new_password: this.info.new_password
          }
        ).then(data => {
          console.log(data);
          if (data.Code == 0) {
            this.toast("修改成功，请重新登录");
            this.$router.push("/login");
          } else {
            this.toast(data.Data.msg);
          }
        });
      }
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.agent_edit_base input {
  margin-left: 0;
}
</style>
