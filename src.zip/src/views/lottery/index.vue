<template>
  <div class="td-warp" style="margin-bottom:-1.3rem">
      <m-header :showBack="false" title="开奖记录"><router-link to="/betTeMa/1" slot="right" class="cur">下注</router-link></m-header>
      <div class="bgff tb-content-warp" :class="isIos?'iosMarginTop':''">
          <div class="lottery-header lh54">
            <p>
              <span class="mr54 f26">第{{info.award_date}}期</span>
              <span class="c666">{{info.award_time}}</span>
            </p>
            <p>
              <span class="mr54 f26">开奖号码:</span>
              <span class="c666 carcel" :class="'bet-bg-'+infoCode[0].cate">{{infoCode[0].cate_num}}</span>
              <span class="c666 carcel" :class="'bet-bg-'+infoCode[1].cate">{{infoCode[1].cate_num}}</span>
              <span class="c666 carcel" :class="'bet-bg-'+infoCode[2].cate">{{infoCode[2].cate_num}}</span>
              <span class="c666 carcel" :class="'bet-bg-'+infoCode[3].cate">{{infoCode[3].cate_num}}</span>
              <span class="c666 carcel" :class="'bet-bg-'+infoCode[4].cate">{{infoCode[4].cate_num}}</span>
              <span class="c666 carcel" :class="'bet-bg-'+infoCode[5].cate" style="margin-right:.17rem">{{infoCode[5].cate_num}}</span>
              <span>+</span>
              <span class="c666 carcel" :class="'bet-bg-'+infoCode[6].cate" style="margin-left:.17rem">{{infoCode[6].cate_num}}</span>
            </p>
            <p>
              <span class="mr54 f26">正码生肖:</span>
              <span class="mr10 c666">{{info.zodiac_one}}</span>
              <span class="mr10 c666">{{info.zodiac_two}}</span>
              <span class="mr10 c666">{{info.zodiac_three}}</span>
              <span class="mr10 c666">{{info.zodiac_four}}</span>
              <span class="mr10 c666">{{info.zodiac_five}}</span>
              <span class="mr40 c666">{{info.zodiac_six}}</span>
              <span class="c666">色波：{{info.colors}}</span>
            </p>
          </div>
          <div class="lottery-te btn" style="padding:0px;">
              <span class="flex">特码</span>
              <span style="width:2px;background-color:#fff;display:inline" ></span>
              <span class="flex">总数</span>            
          </div>
          <div style="-webkit-box-shadow: 0px 3px 8px #ccc; box-shadow: 0px 3px 8px #ccc;">
          <div class="lottery-sheng lh60 f28 c333">
              <p class="disFlex">
                <span class="flex">生肖</span>
                <span class="flex">单双</span>
                <span class="flex">大小</span>
                <span class="flex">尾数</span>
              </p>
              <p style="width:2px;background-color:#c9c9c9;" ></span>
              <p class="disFlex">
                <span class="flex">总和</span>
                <span class="flex">单双</span>
                <span class="flex">大小</span>
              </p>
          </div>
          <div class="lottery-sheng lh50 f24 c7a7" >
              <p class="disFlex">
                <span class="flex">{{info.zodiac_seven}}</span>
                <span class="flex">{{info.t_single_double}}</span>
                <span class="flex">{{info.t_big_small}}</span>
                <span class="flex">{{info.t_last_num_big_small}}</span>
              </p>
              <p style="width:2px;background-color:#c9c9c9;" ></span>
              <p class="disFlex">
                <span class="flex">{{info.sums}}</span>
                <span class="flex">{{info.sums_single_double}}</span>
                <span class="flex">{{info.sums_big_small}}</span>
              </p>
          </div>
          </div>
      </div>
  </div>

</template>

<script>
import MHeader from '@/components/header'
export default {
  components:{
    MHeader
  },
  data () {
    return {
        info:{},
        infoCode:[{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''}],
    }
  },
  created(){   
    this.awardRecord();
  },
  methods:{
    awardRecord(){
       this.$http('award/award_record',{level:this.level,curpage:this.page}).then(res=>{
          if(res.code==200){
              this.info = res.data[0]; 
              this.infoCode = res.data[0].code;
          }else service.openToast(true,res.msg);
      })
    }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

  .lottery-header{padding-left:.24rem;padding-top:.18rem;padding-bottom:.18rem}
  .lottery-header  .carcel{margin-right:.26rem;display:inline-block;border-radius: 50%;background-color:#dd2638;width:.4rem;height:.4rem;text-align: center;color:#fff;line-height: .4rem;}
  .lottery-te{color:#fff;font-size: .28rem;line-height: .78rem;text-align: center;display: flex;}
  .lottery-te .flex{flex:1;}
  .lottery-sheng{display: flex;background-color: #fff; }
  .lottery-sheng .disFlex{flex:1;display: flex;}
  .lottery-sheng .flex{flex:1;text-align: center;}

</style>
