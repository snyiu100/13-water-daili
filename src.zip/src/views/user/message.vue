<template>
  <div class="td-warp">
      <m-header :showBack="true" title="消息纪录"></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
           <scroller :on-refresh="onRefresh" :on-infinite="onInfinite" v-if="lists.length>0" :class="isIos?'iosMarginTop':''" ref="my_scroller" :style="isIos?'margin-top:1.1rem':'margin-top:.9rem'">
          <ul class="money-list">
              <li v-for="(vm,index) in lists" :key="index">
                <div class="title">{{vm.add_time}}</div>
                <div class="winn-date">{{vm.content}}</div>
              </li>
          </ul>
        </scroller>
        <div class="node-pic" v-else><img src="../../assets/images/home/node-pic.png" ><p>暂无数据，请您继续努力</p></div>
      </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
export default {
  components:{
    MHeader,
  },
  data () {
    return {
        lists:[],
        page:0,
    }
  },
  mounted(){
     this.messageMsg();
  },
  methods:{
    messageMsg(){
      this.page = 0;
      this.$http('Message/msg',{curpage:this.page},true).then(res=>{
        if(res.code==200){
          this.lists = res.data;
        }
      })
    },
    onRefresh(done){
        this.messageMsg();
        done();
    },
    onInfinite(done){
       this.page =  this.page+1;
      this.$http('Message/msg',{curpage:this.page},true).then(res=>{
           if(res.code==200){
            if(res.data.length < 1){
                 this.$refs.my_scroller.finishInfinite(2);
                 return 
            }
            this.lists = this.lists.concat(res.data);
            done(); // call done
          }
      })
    }
    
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
  .money-list{ 
    li{border-bottom:1px solid #c6c6c6; background-color: #fff; padding:.15rem;  clear: both;
      .title{font-size:0.3rem; color:#333;
        span{color:#666666; font-size:.26rem; padding-left:.2rem;}
      }
      .winn-date{
        font-size:.28rem; display: flex; padding-top:0.2rem; color:#666666;
        div{
          &.c3{color:#333;}
          span{padding-left:30%;}
          &:first-child{flex:7}
          &:last-child{flex:3}
        }
      }
     }
  }
</style>
