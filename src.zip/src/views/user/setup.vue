<template>
  <div class="td-warp">
      <m-header :showBack="true" title="设置"></m-header>
      <div class="tb-content-warp"  :class="isIos?'iosMarginTop':''">
        <div class="user-nav-list user-b">
          <!--router-link to="#"><i class="user-icon-3"></i>交易纪录</router-link-->
          <router-link to="/userCard"><i class="user-icon-10"></i>银行卡</router-link>
          <router-link to="/logPassword"><i class="user-icon-9"></i>设置登录密码</router-link>
          <router-link to="/ptPassword"><i class="user-icon-8"></i>设置支付密码</router-link>
        </div>

      </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
export default {
  components:{
    MHeader
  },
  data () {
    return {
      info:{}
    }
  },
  created(){   
    this.userInfo();
  },
  methods:{
      userInfo(){
        this.$http('center/check_user_data',{},true).then(data=>{
          this.info = data.data[0];
        })
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
  .user-header{ border-bottom:1px solid #c6c6c6; 
      .user-header-img{ height:1.5rem; margin:0px 0.2rem; padding:0.5rem 0; border-bottom:1px solid #ddd; color:#333; position: relative;
        background: url('../../assets/images/icon/right.png') no-repeat 96% center; background-size: .5rem;
        img{ height:1.6rem; width:1.6rem; border-radius:50%; vertical-align: sub; margin-left:0.5rem; position: absolute;}
        h3{padding-top:0.3rem; font-size:0.4rem; padding-left:2.5rem;}
        p{ padding-left:2.5rem; padding-top:0.1rem; color:#666666}
      }
      ul{ display: flex; text-align: center; padding:0.28rem 0;
        li{ flex:3; color:#707070;
          p{color:#dd2638}
        }
      }
  }

  .user-nav-list{

     background-color: #fff;
     a{  line-height: 0.95rem; text-indent: 0.3rem; color:#404040; font-size:.3rem;background: url('../../assets/images/icon/right.png') no-repeat 98% center; background-size: 0.5rem;
      i{height:.44rem; width:.44rem; display: inline-block; vertical-align: middle; margin-right: 0.1rem;}
      
     }
     &.user-b{
       a{margin-left:0.3rem;  border-bottom:1px solid #d3d3d3; text-indent: 0;
        &:last-child{border:none;}
        }
     }

  }

  @for $i from 8 through 10 {
    .user-icon-#{$i}{ background: url('../../assets/images/user/user-icon-#{$i}.png') no-repeat center; background-size:0.5rem;}
  }
</style>
