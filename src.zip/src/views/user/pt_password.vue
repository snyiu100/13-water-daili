
<template>
<div class="td-warp bgff">
       <m-header :showBack="true" title="设置提现密码"></m-header>
       <div class="tb-content-warp"  :class="isIos?'iosMarginTop':''">
          <div class="regFrom">
                <input type="password" class="reg_pa" placeholder="请设置提现密码" v-model="info.passwordOne"  />
                <input type="password" class="reg_pa" placeholder="再次输入提现密码" v-model="info.password" />
                <input type="button" value="修改密码"  class="regButton" @click="carry_money_pwd" />
          </div>
       </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import localStorage from '@/common/localStorage'
import TdToast from '@/components/toast'
import service from '@/common/service'

export default {
  components:{
    MHeader,
    TdToast,
  },
  data () {
    return {
      info:{}
    }
  },
  methods:{
    
		carry_money_pwd() {//设置提现密码
      if(!this.info.passwordOne && !this.info.password){
         service.openToast(true,"密码不能为空");
         return false;
      }

      if(this.info.passwordOne != this.info.password){
         service.openToast(true,"两次密码输入不一致");
         return false;
      }

			this.$http('center/carry_money_pwd',{carry_money_pwd:this.info.password},true).then(data=>{
         if(data.code==200){
           service.openToast(true,"设置成功");
         }else{
           service.openToast(true,data.msg);
         };
			})
		}

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
	.xy{ color: #c8c8c8; text-align: center; padding: .2rem 0;}
  .regFrom{padding:0 1rem;margin-top:1rem;}
  .reg_pa{font-size: .28rem;line-height: .28rem;padding:.20rem 0;background-color: #fff;border: 2px solid #ec504c;border-radius: 5px;width:99%;text-indent: .8rem;margin-bottom:.8rem;}
  .regButton{
	padding: .2rem;
	width: 100%;
	border-radius: 5px;
	background: -webkit-linear-gradient(left, #de2839 , #fe8263); /* Safari 5.1 - 6.0 */
    background: -o-linear-gradient(right, #de2839, #fe8263); /* Opera 11.1 - 12.0 */
    background: -moz-linear-gradient(right, #de2839, #fe8263); /* Firefox 3.6 - 15 */
    background: linear-gradient(to right, #de2839 , #fe8263); /* 标准的语法（必须放在最后） */
  color:#fff;}
	.btn_code{width: 30.9%; padding: .22rem 0; border-left: none; border-radius: 0 5px 5px 0; text-indent: 0rem;}
</style>
