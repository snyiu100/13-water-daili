<template>
  <div class="td-warp">
      <m-header :showBack="true" title="意见反馈"></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
        <div class="feed-txt pt30">
          <textarea placeholder="请填写1-80个字的意见和建议" class="pt20" maxlength="80" onchange="this.value=this.value.substring(0, 80)" v-model="info.content"></textarea>
          <input type="text" class="mt30" placeholder="请填写您的邮箱或手机号" v-model="info.phone_or_email"/>
          <div class="btn ml80 mt40 mr80 br3 cur" @click="onFeedBack()">提交</div>
        </div>
      </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import service from '@/common/service'
export default {
  components:{
    MHeader
  },
  data () {
    return {
      info:{}
    }
  },
  created(){   

  },
  methods:{
      onFeedBack(){
        if(!this.info.content){
          service.openToast(true,'意见和建议不能为空！');
          return false;
        }
        if(!this.info.phone_or_email){
          service.openToast(true,'邮箱或手机号不能为空！');
          return false;
        }

        this.$http('center/suggest',this.info).then(data=>{
          if(data.code==200){
              service.openToast(true,"反馈成功");
              this.$router.push({ path: '/userIndex'});
          }else service.openToast(true,data.msg);
        })
      }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
  .feed-txt{
      textarea{height: 3rem;}
      input{ line-height: 1rem; height:1rem;}
      textarea,input{ text-indent: 0.2rem;
        background-color: #fff; border:none; width:90%; margin-left:5%; border-radius: 3px;  -webkit-box-shadow: 0px 0px 5px #ddd; box-shadow: 0px 0px 5px #ddd;
      }
  }
</style>
