<template>
  <div class="td-warp">
      <m-header :showBack="false" title="我的"></m-header>
      <div class="tb-content-warp" style="padding-bottom:1.35rem;" :class="isIos?'iosMarginTop':''">
        <div class="user-header bgff">
              <router-link to="/userInfo" class="user-header-img">
                <img :src="info.avatar">
                <h3>{{info.user_name||'匿名'}}</h3>
                <p>查看或编辑个人资料</p>
              </router-link>
              <ul>
                <li @click="routerGo(1)">{{info.money}}<p>金额</p></li>  
                <li @click="routerGo(2)">{{info.carry_money}}<p>提现</p></li>  
                <li>{{info.profit}}<p>今日收益</p></li>  
              </ul>
        </div>
        <div class="user-nav-list mt15">
          <router-link to="/userWinning"><i class="user-icon-1"></i>投注/中奖记录</router-link>
        </div>
        <div class="user-nav-list mt15">
          <router-link to="/userMoneyDetaile"><i class="user-icon-2"></i>充值/提现记录</router-link>
        </div>
        <div class="user-nav-list mt15 user-b">
          <!--router-link to="#"><i class="user-icon-3"></i>交易纪录</router-link-->
          <router-link to="/userShare"><i class="user-icon-4"></i>分享给好友</router-link>
          <router-link to="/userMessage"><i class="user-icon-5"></i>消息记录</router-link>
          <router-link to="/userFeedBack"><i class="user-icon-6"></i>用户反馈</router-link>
        </div>
        <div class="user-nav-list mt15">
          <router-link to="/userSetup"><i class="user-icon-7"></i>设置</router-link>
        </div>
        <div class="logout mt20" @click="logout()">退出</div>
      </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import storage from '@/common/localStorage'
import service from '@/common/service'
export default {
  components:{
    MHeader
  },
  data () {
    return {
      info:{}
    }
  },
  created(){   
    this.userInfo();
  },
  methods:{
      //获取用户信息
      userInfo(){
        this.$http('center/check_user_data',{},true).then(data=>{
          this.info = data.data[0];
        })
      },
      routerGo(id){
        this.$router.push({ path: '/accessMoney/'+id});
      },
      //退出
      logout(){
        storage.setItem('user_id','');
        service.openHeader(false);
        service.openToast(true,"退出成功");
        this.$router.push({ path: '/login' });
        
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
  .user-header{ border-bottom:1px solid #c6c6c6; 
      .user-header-img{ height:1.5rem; margin:0px 0.2rem; padding:0.5rem 0; border-bottom:1px solid #ddd; color:#333; position: relative;
        background: url('../../assets/images/icon/right.png') no-repeat 96% center; background-size: .5rem;
        img{ height:1.6rem; width:1.6rem; border-radius:50%; vertical-align: sub; margin-left:0.5rem; position: absolute;}
        h3{padding-top:0.3rem; font-size:0.4rem; padding-left:2.5rem;}
        p{ padding-left:2.5rem; padding-top:0.1rem; color:#666666}
      }
      ul{ display: flex; text-align: center; padding:0.28rem 0;
        li{ flex:3; color:#707070;
          p{color:#dd2638}
        }
      }
  }

  .user-nav-list{

     background-color: #fff;
     a{  line-height: 0.95rem; text-indent: 0.3rem; color:#404040; font-size:.3rem;background: url('../../assets/images/icon/right.png') no-repeat 98% center; background-size: 0.5rem;
      i{height:.44rem; width:.44rem; display: inline-block; vertical-align: middle; margin-right: 0.1rem;}
      
     }
     &.user-b{
       a{margin-left:0.3rem;  border-bottom:1px solid #d3d3d3; text-indent: 0;
        &:last-child{border:none;}
        }
     }

  }

  .logout{ background-color: #fff; line-height: 0.95rem; color:#dd2638; font-size:0.3rem; text-align: center; cursor: pointer;}

  @for $i from 1 through 7 {
    .user-icon-#{$i}{ background: url('../../assets/images/user/user-icon-#{$i}.png') no-repeat center; background-size:0.5rem;}
  }
</style>
