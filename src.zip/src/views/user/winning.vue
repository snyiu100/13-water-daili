<template>
  <div class="td-warp">
      <m-header :showBack="true" title="中奖记录"></m-header>
      <div class="tb-content-warp"  :class="isIos?'iosMarginTop':''">
        <t-dtabs :lists="tabs" v-model="istab"></t-dtabs>
        <div>
          <scroller :on-refresh="onRefresh" :on-infinite="onInfinite" v-if="lists.length>0" ref="my_scroller" style="margin-bottom:-1.9rem;" :style="isIos?'margin-top:2.3rem':'margin-top:1.81rem'">
                <ul class="winning-list">
                  <li v-for="(vm,index) in lists" :key="index">
                      <div class="title">香港六合彩<span>{{vm.award_date}}期</span><span>{{vm.cate}}</span><span class="r cdd2" v-if="level==2">{{vm.money==0?'未中奖':'已中奖：'+vm.money}}</span></div>
                      <div class="winn-date"><div>{{vm.add_time}}<span style="padding-left:1.19rem;">投注数：{{vm.up.length>0?vm.up.length:vm.down.length}}</span></div><div class="cdd2 text-right">投注金额：{{vm.touzhu_jine}}</div></div>
                      <div class="winn-tema-6" v-if="vm.type==13">
                            <div v-for="(down,index) in vm.down" :key="index">{{down.category}}&nbsp;&nbsp;(<span v-for="(cate,cindex) in down.nums" :key="cindex">{{cate.bet_down|zhenMa}},</span>)</div>
                      </div> 
                      <div v-else>
                        <div class="winn-date winn-kj" v-if="vm.up.length>0">
                            <span v-for="(up,index) in vm.up" :key="index" :class="'bet-bg-'+up.cate">{{up.cate_num}}</span>
                        </div>
                        <div class="winn-date " v-if="vm.down.length>0">
                            <span v-for="(up,index) in vm.down" :key="index" class="pl10 pr10" >{{up.category}}</span>
                        </div>
                      </div>
                  </li>
                </ul>
            </scroller>
            <div class="node-pic" v-else><img src="../../assets/images/home/node-pic.png" ><p>暂无数据，请您继续努力</p></div>
        </div>
      </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
import TDtabs from '@/components/tabs'
export default {
  components:{
    MHeader,
    TDtabs,
  },
  data () {
    return {
      tabs:['投注记录','中奖记录'],
      istab:0,
      lists:[],
      page:0,
      level:1,
      hasmore: true //暂无更多数据显示

    }
  },
  watch:{
      istab(val){
        this.lists = [];
        this.level = parseInt(val+1);
        this.page = 0;
        this.winPrize();
      }
  },
  created(){   
    this.winPrize();
  },
  methods:{
    winPrize(){
        this.$http('center/win_prize',{level:this.level,curpage:0},true).then(res=>{
            if(res.code==200){
              this.lists = res.data;
            }
        })
    },
    onRefresh(done){
       this.page = 0;
       this.winPrize();
       done(); // call done
    },
    onInfinite(done){
      console.log(this.hasmore);
        if(!this.hasmore){
            return 
        }
       this.page =  this.page+1;
       this.$http('center/win_prize',{level:this.level,curpage:this.page},true).then(res=>{
          if(res.code==200){
            console.log(res.hasmore);
            if(!res.hasmore){
                 this.hasmore = false;
                 this.$refs.my_scroller.finishInfinite(2);
                 return 
            }
            this.lists = this.lists.concat(res.data);
           
            done(); // call done
          }
        
      })

    }
  },
  filters:{
     zhenMa(val){
        var info = '正码一'; 
        if(val==2){
           info = '正码二'; 
        }
        if(val==3){
           info = '正码三'; 
        }
        if(val==4){
           info = '正码四'; 
        }
        if(val==5){
           info = '正码五'; 
        }
        if(val==6){
           info = '正码六'; 
        }
        return info;
     }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
  .winning-list{ 
    li{border-bottom:1px solid #c6c6c6; background-color: #fff; padding:.15rem;  clear: both;
      .title{font-size:0.3rem; color:#333;
        span{color:#666666; font-size:.26rem; padding-left:.2rem;}
      }
      .winn-date{
        display: flex; padding-top:0.2rem; color:#666666;
        div{
          &.c3{color:#333;
              span{padding-left:31%;}
          }
          &:first-child{flex:7}
          &:last-child{flex:3}
        }
      }
     }
  }
  .winn-tema-6{width:100%; padding-top: 0.2rem;
    div{padding:0.1rem ;span{ color:#666666;}}
  }
  .winn-kj{
    span{
      margin-right: .26rem;
      display: inline-block;
      border-radius: 50%;
      background-color: #dd2638;
      width: .4rem;
      height: .4rem;
      text-align: center;
      color: #fff;
      line-height: .4rem;
    }
  }
</style>
