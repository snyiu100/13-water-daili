<template>
  <div style="background-color:#efefef">
    <div id="bet_header">
      <div class="bet-header bgff">
        <div class="bet-h-c">
          <p>距离截止下注还有</p>
          <ul>
            <li class="time">{{time.h}}</li>
            <li>:</li>
            <li class="time">{{time.m}}</li>
            <li>:</li>
            <li class="time">{{time.s}}</li>
          </ul>
        </div>
        <div class="bet-h-c">
            <span>当前期数：</span>{{info.award_date}}期<br/>
            <span>开奖时间：</span>{{info.award_time}}<br/>
            <span>封盘时间：</span>{{info.close_time}}<br/>
        </div>
      </div>
      <div v-if="stauts" class="bet-kj bet-rad-hui mt15 bgff clearfix">{{info.award_date}}期开奖
          <ul>
            <li :class="'bet-bg-'+infoCode[0].cate">{{infoCode[0].cate_num}}</li>
            <li :class="'bet-bg-'+infoCode[1].cate">{{infoCode[1].cate_num}}</li>
            <li :class="'bet-bg-'+infoCode[2].cate">{{infoCode[2].cate_num}}</li>
            <li :class="'bet-bg-'+infoCode[3].cate">{{infoCode[3].cate_num}}</li>
            <li :class="'bet-bg-'+infoCode[4].cate">{{infoCode[4].cate_num}}</li>
            <li :class="'bet-bg-'+infoCode[5].cate">{{infoCode[5].cate_num}}</li>
            <li class="jia">+</li>
            <li style="margin:0px;" :class="'bet-bg-'+infoCode[6].cate">{{infoCode[6].cate_num}}</li>
         </ul>
      </div>
    </div>
  </div>
</template>

<script>
import storage from '@/common/localStorage'
export default {
   props: {
      stauts: {
         type: Boolean,
         default: true
      }
  },
  data () {
    return {
      info:{},
      infoCode:[{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''},{cate:'',cate_num:''}],
      time:{
        h:'00',
        m:'00',
        s:'00'
      },
    }
  },
  created(){   
    this.awardRecord();
  },
  methods:{
    awardRecord(){
       let that = this;
       this.$http('award/award_record',{level:this.level,curpage:this.page}).then(res=>{
          if(res.code==200){
              storage.setItem('award_date',res.data[0].award_date);
              this.info = res.data[0]; 
              this.infoCode = res.data[0].code;
              // 获取时间格式的时间戳
              let close_times = Date.parse(new Date(res.data[0].close_time.replace(/-/g, '/')));//封盘的时间戳
              let time = Date.parse(new Date());//当前时间戳
              let timeDate=close_times-time;
			        let interval=null;
              //console.log(close_time,time,timeDate);
              if(timeDate>1000){
                //timeDown(timeDate);
                interval = setInterval(function() {
                        let h = Math.floor(timeDate/1000/3600);
                        let m = Math.floor(timeDate/1000%3600/60);
                        let s = Math.floor(timeDate/1000%60);
                        h = h < 10 ? "0" + h : h;
                        m = m < 10 ? "0" + m : m;
                        s = s < 10 ? "0" + s : s;
                        that.time.h=h;
                        that.time.m=m;
                        that.time.s=s;
                        if (h==0 && m == 0 && s == 0) {
                            clearInterval(interval)
                            /*结束倒计时*/
                        }
                        timeDate=timeDate-1000;
                        //console.log(h + ":" +m + ":" + s)
                      }, 1000);
                      
              }else{
                  /*结束倒计时*/
                  that.time.h='00';
                  that.time.m='00';
                  that.time.s='00';
              };

          }else service.openToast(true,res.msg);
      })
    }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    #bet_header{
        width:100%;background-color:#efefef; height:143px; overflow: hidden;
          }
    .bet-header{
        
        top:1rem;
        display: flex;
        border-bottom:1px solid #c6c6c6;
        .bet-h-c{
          &:first-child{flex: 1.4; border-right: 1px solid #c6c6c6; padding-left: 10px;
            p{color:#333; padding-top: 15px; font-size:13px;}
            ul{ padding-top: 15px;
              li{ text-align: center; height:25px; line-height: 25px; float: left; width:15px;
                &.time{background-color: #fe5346; color:#fff; font-size:14px; width:25px;}
              }
            }
          }
          &:last-child{flex: 2; padding:15px; line-height: 20px; font-size:13px; color:#666666;
            span{color:#333;}
          }
        }
    }
    .bet-kj{  height: 30px; position: relative;  font-size: 14px;  padding: 8px; margin-top: 5px; line-height: 30px;
        ul {
           top:10px;
           li{
                 height: 25px; width: 25px; font-size: 14px; line-height: 25px; margin-left:5px;
                 &.jia{ width:15px; margin:0px;}
           }
        }
    }
@media (min-width: 320px) {
  .bet-header .bet-h-c:last-child{font-size: 11.5px;}
  .bet-kj ul li{width:22px; height:22px; line-height: 22px;}

}
</style>