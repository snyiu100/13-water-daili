<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" title="正码1-6"><router-link to="/" slot="left" class="go-back"></router-link><span slot="right" class="cur"><router-link to="/rules">规则</router-link></span></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
         <bet-header></bet-header>
         <m-warp class="bgff">
             <!--div v-for="(vm,index) in ls" :key="index">
                 {{vm.cate_name}}
                 <span v-for="(cate,cindex) in vm.cate_num" :key="cindex">{{cate.number}}</span>
             </div-->
       
            <div class="zhengMaSix cfff">
                <ul class="bged f26 lh58">
                    <li style="width:.88rem;margin:auto 0;">类型</li>
                    <li class="liFlex">
                        <p>正码一</p>
                        <p class="f22">
                            <span>赔率</span>
                            <span>金额</span>
                        </p>
                    </li>
                    <li class="liFlex">
                        <p>正码二</p>
                        <p class="f22">
                            <span>赔率</span>
                            <span>金额</span>
                        </p>
                    </li>
                    <li class="liFlex">
                        <p>正码三</p>
                        <p class="f22">
                            <span>赔率</span>
                            <span>金额</span>
                        </p>
                    </li>
                    <li class="liFlex">
                        <p>正码四</p>
                        <p class="f22">
                            <span>赔率</span>
                            <span>金额</span>
                        </p>
                    </li>
                    <li class="liFlex">
                        <p>正码五</p>
                        <p class="f22">
                            <span>赔率</span>
                            <span>金额</span>
                        </p>
                    </li>
                    <li class="liFlex">
                        <p>正码六</p>
                        <p class="f22">
                            <span>赔率</span>
                            <span>金额</span>
                        </p>
                    </li>
                </ul>
            </div>
            <div class="zhengMaSix c666 zhengMaSixTwo" v-for="(vm,index) in lists.data" :key="index">
                <ul class="bgff f26 lh58">
                    <li style="width:.88rem;margin:auto 0;" :class="'bet-bg-'+vm.cate">{{vm.category}}</li>
                    <li class="liFlex">
                        <p>{{vm.odd[0].z_code_one}}</p>
                        <p><t-input v-model="vm.odd[0].money"></t-input></p>
                    </li>
                    <li class="liFlex">
                        <p>{{vm.odd[1].z_code_two}}</p>
                        <p><t-input v-model="vm.odd[1].money"></t-input></p>
                    </li>
                    <li class="liFlex">
                        <p>{{vm.odd[2].z_code_three}}</p>
                        <p><t-input v-model="vm.odd[2].money"></t-input></p>
                    </li>
                    <li class="liFlex">
                        <p>{{vm.odd[3].z_code_four}}</p>
                        <p><t-input v-model="vm.odd[3].money"></t-input></p>
                    </li>
                    <li class="liFlex">
                        <p>{{vm.odd[4].z_code_five}}</p>
                        <p><t-input v-model="vm.odd[4].money"></t-input></p>
                    </li>
                    <li class="liFlex">
                        <p>{{vm.odd[5].z_code_six}}</p>
                        <p><t-input v-model="vm.odd[5].money"></t-input></p>
                    </li>
                </ul>
            </div>
         </m-warp>
      </div>
      <bet-model v-model="isModel" @on-confirm="savePayBet" :info="betArr" :maSix="maSix"></bet-model>
      <bet-footer></bet-footer>
  </div>

</template>

<script>
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import service from '@/common/service'
import TInput from '@/components/t-input'
import {isBet} from "@/common/state"
import {shengXiaokDateSix} from '@/common/bet'
import BetModel from './betModel'
import BetFooter from './betFooter'
import BetHeader from './betHeader'
export default {
  components:{
    MHeader,
    MWarp,
    BetFooter,
    BetHeader,
    BetModel,
    TInput
  },
  data () {
    return {
        isbet:isBet,
        maSix:false,
        ls:[{ "cate": 0, "cate_name": "大", "cate_num": [{ "z_code_three": "1.96", "money": "5", "number": 1 }, {"z_code_four": "1.96", "money": "5", "number": 2 } ] } ],
        betArr:{bet:[],data:[]},
        isModel:false,
        info:{
            up:[{id:'',money:''}],
            down:[],
            betting_lx:[{type:13,two_type: 0,three_type: 0,money: '0',fast:1}]
        },
        lists:[]
    }
  },
  created(){   
    this.betShow();
  },
  methods:{
    //获取数据  13:正码1-6
    betShow(){
      this.$http('bet/bet_show',{level:13}).then(res=>{
          if(res.code==200){
            for(let i in res.data){
                for(let j in res.data[i].odd){
                    res.data[i].odd[j].money = '';
                }
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    //提交下注
    betSave(){
      this.maSix = true;
      this.info.down =  shengXiaokDateSix(this.lists.data);
      if(this.info.down.length<1){
          service.openToast(true,"尚未输入金额");
          return false;
      } 
      service.betOrder(this.info).then(res=>{
          if(res.code==200){
              this.isModel = true;
              this.betArr = res;
              this.betShow();
          }else service.openToast(true,res.msg);
      })
    },
     //弹出框下注
    savePayBet(){

    },       
    //清空设置
    clearAll(){
        for(let i in this.lists.data){
            for(let j in this.lists.data[i].odd){
                this.lists.data[i].odd[j].money = '';
            }
        }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    body{background-color: #efefef}
    .bet-kj{
      position: relative; font-size:.28rem; padding: .25rem;
      ul{ position: absolute; right:.2rem; top:.25rem;
        li{height:0.4rem; width:0.4rem; float: left; margin-left:0.2rem; font-size:.2rem; border-radius: 50%; background-color:#dd2638; color:#fff; line-height: .4rem; text-align: center;
          &.jia{background-color: transparent; color:#333;margin-left:0px;}
        }
      }
    }
    .bet-tez{
        ul{
          display: flex; 
          li{flex:1;}
          &.bet-tez-check{
             li{cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat left center; font-size:.24rem; text-indent: .38rem; padding:.25rem 0px; background-size: .35rem;
              &.active{background: url('../../assets/images/icon/checked.png') no-repeat left center;  background-size: .35rem;}
            }
          }
        }
    }
  
    .bet-tez-checked{
      display: flex;
        div{  flex: 1;
           padding-left: 0.2rem;
          span{ cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat left center;   background-size: .45rem; padding-left:.5rem;
            &.active{
               background: url('../../assets/images/icon/checked.png') no-repeat left center;   background-size: .45rem; 
            }
          }
        }
    }

.zhengMaSix{
    .bet-bg-1{ background-color: #dd2638!important;color: #fff!important;}
    .bet-bg-2{ background-color: #1EA613!important;color: #fff!important;}
    .bet-bg-3{ background-color: #0D689C!important;color: #fff!important;}
    .liFlex{
            flex:1;
        };
    ul{
        display:flex;
        
        li{
            text-align: center;
            border-left:1px solid #fff;
            //padding:0 1px;
           
        }
        li:first-child{
            border-left:0;
        }
    }
}
.zhengMaSixTwo{
    font-size: .24rem;
    .liFlex{
            flex:1;
            display:flex;
            input{background-color: transparent; text-align: center; border:none; width:100%;}
        };
    ul{
        line-height: .68rem;
        border-bottom:1px solid #c6c6c6;
        li{
            border-right:1px solid #8e8e8e;
            p{
             flex:1;
             border-right:1px solid #c6c6c6;   
            }
            p:last-child{
             border-right:1px solid #fff;
            }
        }
        li:last-child{
            border-right:0;
        }
        .zhengMaSixRed{
            background-color:#ef2c3d;
            color:#fff;
        }
        .zhengMaSixBlue{
            background-color:#0d689c;
            color:#fff;
        }
        .zhengMaSixGreen{
            background-color:#1ea613;
            color:#fff;
        }
    }
}


    .bet-footer{

      position: fixed; bottom: 1.18rem; width:100%;  
      display: flex;
      li{flex:1; text-align: center; font-size:.24rem; cursor: pointer; -webkit-box-shadow: 0px -3px 2px 0px #E7BFC3;;  box-shadow: 0px -3px 2px 0px #E7BFC3;; border-radius: 5px 5px 0 0;  height:.65rem; line-height: .6rem;  background: url('../../assets/images/icon/bet-f.jpg') repeat-x; background-size: contain;
        i{height:.28rem; width:.28rem; display: inline-block; vertical-align: sub; margin-right:.1rem;}
        &:last-child{background: url('../../assets/images/icon/bet-f-a.jpg') repeat-x; color:#fff;}
        &:nth-child(1) i{background: url('../../assets/images/icon/bet-footer-1.png') no-repeat; background-size: cover; }
        &:nth-child(2) i{background: url('../../assets/images/icon/bet-footer-2.png') no-repeat; background-size: cover; }
        &:nth-child(3) i{background: url('../../assets/images/icon/bet-footer-3.png') no-repeat; background-size: cover; }
      } 
    }

</style>