<template>
<div>
  <td-confirm v-model="isMore" @on-confirm="chongzhi()" confirm-text="去充值">您的余额不足请充值</td-confirm>
  <div class="m-confirm" @touchmove="onTouchMove">
     <transition name="vux-mask">
         <div class="weui-mask" v-show="showValue"></div>
     </transition>  
     <transition name="vux-dialog">
         <div class="w-bet-model" v-show="showValue">
          <div class="bet-model-content">
              <ul class="clearfix" v-if="isMaSix">
                  <li v-for="(vm,index) in betDate.bet" :key="index" style="width:100%; text-align:left;">{{vm.cate_name}}&nbsp;&nbsp;<span style="font-size:.24rem;" v-for="(cate,cindex) in vm.cate_num" :key="cindex">{{cate[0].number|zhenMa}}&nbsp;</span></li>
              </ul>
              <ul class="clearfix" v-else>
                  <li v-for="(vm,index) in betDate.bet" :key="index" v-if="typeof(vm.cate_num)==='string'">{{vm.cate_num}}</li>
              </ul>

            <div class="w-bet-model-prompt" v-if="!inputShow">
                  <input class="vux-prompt-msgbox" type="number" min="1" max="100" v-model="moneyCount" placeholder="请输入购买金额"/>元
            </div>
          </div>

            <div class="w-bet-money" v-if="inputShow" style="color:#d81532; padding-bottom:0px;">共{{betDate.data.length>0?betDate.data[0].WIDtotal_amount:0}}元</div>
             <div class="w-bet-money" v-else style="color:#d81532; padding-bottom:0px;">共{{betDate.data.length>0?betDate.data[0].WIDtotal_amount:0}}元</div>
            <div class="w-bet-money" v-if="betDate.data.length>0" >使用余额支付（余额{{betDate.data[0].user_acount||0.00}})元</div>
            <div class="w-dialog__ft">
                <span class="w-dialog__btn" @click="_onCancel">{{cancelText}}</span>
                <span class="w-dialog__btn cdd2" @click="_onConfirm">{{confirmText}}</span>
            </div>
        </div>
    </transition> 
  </div>
</div>
</template>

<script>
import Sdk from '@/common/sdk'
import service from '@/common/service'
import TdConfirm from '@/components/confirm'
export default {
  components:{
    TdConfirm,
  },
  props: {
     info:{
       type:Object,
       default:{}
     },
     maSix:{   //正码1-6
       type:Boolean,
       default:false,
     },
     value: {
       type: Boolean,
       default: false
     },
     confirmText: {
       type: String,
       default: '下注'
     },
     cancelText:  {
       type: String,
       default: '取消'
     },
     inputShow:{
       type:Boolean,
       default:true,
     }
  },
  created () {
    this.showValue = false;
    if (this.value) {
      this.showValue = this.value
    }
  },
  watch: {
    moneyCount(val){
      if(!val) return false; 
      this.fast(val);
    },
    info(val){
      this.betDate = val;
    },
    show (val) {
      this.$emit('update:show', val)
      this.$emit(val ? 'on-show' : 'on-hide')
    },
    value (val) {
      this.showValue = val
    },
    maSix (val){
      console.log(val);
      this.isMaSix = val;
    },
    showValue (val) {
      this.$emit('input', val)
      if (val) {
        if (this.showInput) {
          this.msg = ''
          setTimeout(() => {
            if (this.$refs.input) {
              this.$refs.input.focus()
            }
          }, 300)
        }
        this.$emit('on-show') // emit just after msg is cleared
      }
    }

  },
  data () {
    return {
      isMaSix:false,
      betDate:{bet:[],data:[]},
      moneyCount: '',
      showValue: false,
      isMore:false
    }
  },
  methods: {
    setInputValue (val) {
      this.msg = val
    },
    _onCancel () {
      if(this.showValue){
         this.moneyCount='';
      }
      this.showValue = false
      this.$emit('on-cancel')
    },
   _onConfirm () {
     let infoData = {
        out_trade_no:this.betDate.data[0].WIDout_trade_no,
        money:this.betDate.data[0].WIDtotal_amount
     };
     if(!this.inputShow && this.moneyCount==''){
         service.openToast(true,"输入下注金额");
         return 
     }

     this.$http('bet/bet_z',infoData,true).then(res=>{
        if(res.code==200){
            service.openToast(true,"下注成功");
            this.moneyCount = '';
            this.$parent.betShow();
        }else if(res.code==803){
           this.isMore=true;
           this.$emit('input', false)
        }else service.openToast(true,res.msg);
     })
      this.$emit('on-confirm')
      this.$emit('input', false)
    },
    onTouchMove (event) {
      !this.scroll && event.preventDefault()
    },
    chongzhi(){
      this.$router.push({ path: '/accessMoney/1' });
    },
    fast(money){
      let fastInfo = this.$parent.info;
          fastInfo.out_trade_no=this.betDate.data[0].WIDout_trade_no;
          service.betMoneyOrder(fastInfo,money).then(res=>{
            if(res.code==200){
               this.betDate = res;
            }

          })
    }
  },
  filters:{
     zhenMa(val){
        var info = '正码一'; 
        if(val==2){
           info = '正码二'; 
        }
        if(val==3){
           info = '正码三'; 
        }
        if(val==4){
           info = '正码四'; 
        }
        if(val==5){
           info = '正码五'; 
        }
        if(val==6){
           info = '正码六'; 
        }
        return info;
     }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.w-bet-model {
    position: fixed;
    z-index: 5000;
    width: 90%;
    max-width: 30rem;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%,-50%);
    transform: translate(-50%,-50%);
    background-color: #fff;
    text-align: center;
    border-radius: 5px;
    overflow: hidden;
}

.w-bet-money{
    padding: 0.2rem 0;
    color:#000;
    font-size:.26rem;
}


.w-dialog__ft {
    border-top:1px solid #c3c3c3;
    position: relative;
    line-height: 0.85rem;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
}
.w-dialog__ft .w-dialog__btn:nth-child(1){color:#999999}
.w-dialog__ft .w-dialog__btn:nth-child(2){border-left:1px solid #c3c3c3;}
.w-dialog__btn {
    font-size:.3rem;
    cursor: pointer;
    display: block;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    color: #999999;
    text-decoration: none;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
    position: relative;
}
</style>
