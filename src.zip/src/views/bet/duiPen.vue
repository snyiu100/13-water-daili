<template>
  <div>
    <!--生肖-->
    <div class="shen-xiao-tabale mt10 mb10" v-if="ishow">
        <ul class="clearfix">
             <li v-for="(vm,index) in this.lists" :class="vm.check?'active':''" :key="index" @click="onClickShow(vm)">{{vm.category}}</li>
        </ul>
    </div>
    <!--尾数-->
    <div class="shen-xiao-tabale wei-shu-lm mt10 mb10" v-if="!ishow">
        <ul class="clearfix">
             <li v-for="(vm,index) in this.lists" :class="vm.check?'active':''" :key="index" @click="onClickShow(vm)">{{vm.category}}尾</li>
        </ul>
    </div>
  </div>
</template>

<script>
import service from '@/common/service'
export default {
  props:['ishow'],
  data(){
    return {
        value:15,
        lists:[]
    }
  },
  watch:{
    ishow(val){
      this.value = val?15:12;
    }
  },
  created(){
    this.getBetShow();
  },
  methods:{
    //获取数据
    getBetShow(){
       this.value = this.ishow?15:12;
       this.$http('bet/bet_show',{level:this.value}).then(res=>{
          if(res.code==200){
            for(let i in res.data){
              res.data[i].check = false;
            }
            this.lists= res.data;
          }else  service.openToast(true,res.msg);
      }) 
    },
    onClickShow(vm){
      let parent = this.$parent.$parent.arrUp;
       for(let i in parent){
         if(parent[i].id==vm.id){
            service.openToast(true,"对碰种类不能相同");
            return false;
         }
       }
        console.log();
        let index= this.lists.indexOf(vm);
        for(let i in this.lists){
          this.lists[i].check=false;
        }
        this.lists[index].check=true;   
        this.$emit('input',vm);
    }
  }
}
</script>
<style lang="scss" scoped>
    .shen-xiao-tabale{
      &.wei-shu-lm{
         li{ width:20%;}
      }
      padding:0 .5rem;
          li{width: 25%; float: left; cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat .1rem center; background-size: .5rem; text-indent: 0.6rem; padding:.2rem 0;
            &.active{background: url('../../assets/images/icon/checked.png') no-repeat .1rem center;  background-size: .5rem; }
          }
      }
</style>


