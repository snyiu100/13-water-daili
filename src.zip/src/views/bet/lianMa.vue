<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" title="连码"><router-link to="/" slot="left" class="go-back"></router-link><span slot="right" class="cur"><router-link to="/rules">规则</router-link></span></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
         <bet-header></bet-header>
         <m-warp class="bgff">
            <div class="bet-tez-liangma clearfix"><ul class="bet-tez-check"><li :class="vm.check?'active':''" @click="tezActive(vm)" v-for="(vm,index) in lists.data" :key="index">{{vm.category}}</li></ul></div>
            <div class="bet-tez-liangma bet-rad-hui text-center pb15 clearfix f22"><ul><li>三全中 710</li><li>中二 27</br>&nbsp;中三 110</li><li>二全中 75</li><li>中特 38</br>中二 58</li><li>特串 160</li><li>四中一 1.96</li></ul></div>
            <div class="bet-tez-type-lianma clearfix">
                <div class="pt20 pb20" style="width:23%;"><span :class="isDanTuo==1?'active':''" @click="onTanTuo(1)">正常</span><span class="ml10"  :class="isDanTuo==2?'active':''" @click="onTanTuo(2)">胆拖</span></div>
                <div class="pt20 pb20" style="width:54%;" v-if="duiPengStatus"><span class="ml10" :class="info.betting_lx[0].three_type==161?'active':''" @click="onDuiPeng(161)">生肖对碰</span><span class="ml10" :class="info.betting_lx[0].three_type==162?'active':''" @click="onDuiPeng(162)">尾数对碰</span><span class="ml10" :class="info.betting_lx[0].three_type==163?'active':''" @click="onDuiPeng(163)">肖串尾</span></div>
                <div class="pt20 pb20 text-center" style="width:23%; float:right">胆一&nbsp;{{isDanTuo==2?this.dtArr[0]:''}}&nbsp;&nbsp;胆二&nbsp;{{isDanTuo==2?this.dtArr[1]:''}}</div>
            </div>
            <div class="bet-table" v-if="upDateStatus">
               <ul class="bet-table-h"><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li>金额</li></ul>
               <div class="bet-table-c bgff clearfix">
                  <ul v-for="(vm,index) in lists.down" :key="index">
                    <li><i :class="'bet-bg-'+vm.cate">{{vm.val}}</i></li>
                    <li>{{vm.Odds}}</li>
                    <li :class="vm.check?'active':''" @click="onOdd(vm)"></li>
                  </ul>
               </div>
            </div>
            <!--生肖对碰-->
            <div v-show="info.betting_lx[0].three_type==161" style="border-top:1px solid #c6c6c6;">
              <dui-pen v-model="arrUp[0]" :ishow="true"></dui-pen>
              <hr></hr>
              <dui-pen v-model="arrUp[1]" :ishow="true"></dui-pen>
            </div>
            <!--尾数对碰-->
            <div v-show="info.betting_lx[0].three_type==162">
              <dui-pen v-model="arrUp[0]" :ishow="false"></dui-pen>
              <hr></hr>
              <dui-pen v-model="arrUp[1]" :ishow="false"></dui-pen>          
            </div>
            <!--肖串尾-->
            <div v-show="info.betting_lx[0].three_type==163">
              <dui-pen v-model="arrUp[0]" :ishow="true" isdui="15"></dui-pen>
              <hr></hr>
              <dui-pen v-model="arrUp[1]" :ishow="false" isdui="12"></dui-pen>
            </div>
            </m-warp>
         </div>
      <bet-model v-model="isModel" :inputShow="false" :info="betArr"></bet-model>
      <bet-footer></bet-footer>
  </div>

</template>

<script>
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import service from '@/common/service'
import {isBet} from "@/common/state"
import BetFooter from './betFooter'
import BetHeader from './betHeader'
import {shengXiaoCheckDate} from '@/common/bet'
import DuiPen from './duiPen'
import BetModel from './betModel'
export default {
  components:{
    MHeader,
    MWarp,
    BetFooter,
    BetHeader,
    DuiPen,
    BetModel
  },
  data () {
    return {
      lists:[],
      upDateStatus:true,   //true 显示连码   false 显示对连
      duiPengStatus:false,
      isModel:false,
      betArr:{bet:[],data:[]},
      isDanTuo:0,   //1 正常   2 胆拖
      dtArr:[],
      duiArrs:[],//对碰信息
      arrUp:[],
      info:{
        up:[],  
        down:[],
        betting_lx:[{type: 5,two_type: 0,three_type: 0,money: '0',fast:2}]    //three_type:3 生肖对碰   4 尾数对碰   5 肖串尾
      }
    }
  },
  created(){   
    this.betShow();
  },
  methods:{

    //1 正常   2 胆拖
    onTanTuo(i){
      this.upDateStatus=true;
      this.isDanTuo=i;
      this.info.betting_lx[0].three_type=0;
    },
    //3 生肖对碰   4 尾数对碰   5 肖串尾
    onDuiPeng(i){
      this.upDateStatus=false;
      this.info.betting_lx[0].three_type = i;
      this.isDanTuo = 0;
    },
    tezActive(vm){
      let index = this.lists.data.indexOf(vm);
      for(let i in this.lists.data){
        this.lists.data[i].check=false;
      }
      this.lists.data[index].check=true;
      this.info.betting_lx[0].two_type = vm.id;
      this.onTypeUp(vm);
    },
    //中间选项
    onTypeUp(vm){
      if(vm.id==30 || vm.id==31 || vm.id==32){
        this.duiPengStatus=true;
        this.upDateStatus=false;
        this.info.betting_lx[0].three_type = 161;
        this.isDanTuo = 0;
      }else{
        this.upDateStatus=true;
        this.duiPengStatus=false;
        this.info.betting_lx[0].three_type = 0;
      }

    },
    getThinking(betlsit){
        let two_type = this.info.betting_lx[0].two_type,flag = true;
        if(two_type==28 && betlsit.length!=3){
          service.openToast(true,"三全中请选择3位数");
          flag = false;
        }
        if(two_type==29 && betlsit.length!=3){
          service.openToast(true,"三中二请选择3位数");
          flag = false;
        }
        if(two_type==30&& betlsit.length!=2){
          service.openToast(true,"二全中请选择2位数");
          flag = false;
        }
        if(two_type==31 && betlsit.length!=2){
          service.openToast(true,"二中特请选择2位数");
          flag = false;
        }
        if(two_type==32 && betlsit.length!=2){
          service.openToast(true,"特串请选择2位数");
          flag = false;
        }
        if(two_type==33 && betlsit.length!=4){
          service.openToast(true,"四中一请选择4位数");
          flag = false;
        }
        return flag;
    }, 
   //选择种类
    onOdd(vm){
      let index = this.lists.down.indexOf(vm);
      let three_type = this.info.betting_lx[0].three_type;
      if((three_type==30 || three_type==31 || three_type==32) && (this.arrUp[0].id==vm.id || this.arrUp[1].id==vm.id)){
          service.openToast(true,"种类不能相同"); 
          return false;
      }
      console.log(1111111111111);
      if(vm.check){
          for(let i in this.dtArr){
             if(this.lists.down[index].val==this.dtArr[i]){
               this.dtArr.splice(i,1);
             }
          }
          this.lists.down[index].check = false;
      }else{
         this.dtArr.push(this.lists.down[index].val);
         this.lists.down[index].check = true;
      }
      
    },
    //获取数据
    betShow(){
      //获取连码数据
      this.$http('bet/bet_show',{level:5}).then(res=>{
          if(res.code==200){
            for(let i in res.down){
              res.down[i].check = false;
            }
            for(let i in res.data){
              if(i==0){
                  res.data[i].check=true;
                  this.info.betting_lx[0].two_type = res.data[i].id;
              }else res.data[i].check = false;
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    //提交下注
    betSave(){
      if(this.info.betting_lx[0].two_type==30 || this.info.betting_lx[0].two_type==31 || this.info.betting_lx[0].two_type==32){
        if(this.isDanTuo>0){
          this.info.down = [{id:'',money:''}];
          this.info.up =  shengXiaoCheckDate(this.lists.down);
          if(!this.getThinking(this.info.up)){
            return false;
          }
          console.log('down',this.info);
        }else{
          console.log("up");
          this.info.down =  shengXiaoCheckDate(this.arrUp);
          this.info.up = [{id:'',money:''}];
          if(!this.getThinking(this.info.down)){
            return false;
          }
          console.log('up',this.info);
        }
      }else{
         this.info.down = [{id:'',money:''}];
         this.info.up =  shengXiaoCheckDate(this.lists.down);
         console.log('down',this.info);
         if(!this.getThinking(this.info.up)){
            return false;
         }
      }
      service.betOrder(this.info).then(res=>{
          if(res.code==200){
              //this.info.betting_lx[0].three_type = 0;
              this.isModel = true;
              this.betArr = res;
          }else service.openToast(true,res.msg);
      })
    },   
    //清空设置
    clearAll(){
        for(let i in this.lists.data){
            this.lists.data[i].check = false;
        }
        for(let i in this.lists.down){
            this.lists.down[i].check = false;
        }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

    .bet-tez-type-lianma{
        div{
          float:left;
             span{cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat left center; font-size:.24rem; background-size: .30rem; padding-left: .3rem;
              &.active{background: url('../../assets/images/icon/checked.png') no-repeat left center;  background-size: .30rem;}
          }
        }
    }
    
    .bet-tez-checked{
      display: flex;
        div{  flex: 1;
           padding-left: 0.2rem;
          span{ cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat left center;   background-size: .45rem; padding-left:.5rem;
            &.active{
               background: url('../../assets/images/icon/checked.png') no-repeat left center;  background-size: .45rem; 
            }
          }
        }
    }

    .bet-tez-liangma{
        ul{
          width:100%;
          li{ float: left; width:17%;
            &:nth-child(5){width:14%;}
          }
          &.bet-tez-check{
             li{cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat left center; font-size:.24rem; text-indent: .38rem; padding:.20rem 0px; background-size: .35rem;
              &.active{background: url('../../assets/images/icon/checked.png') no-repeat left center;  background-size: .35rem;}
            }
          }
        }

    }

    .bet-table-h{ height:0.5rem; margin-top:0.1rem;
      li{ width:11.1%; font-size:.26rem; border-bottom:1px solid #c6c6c6; border-top:1px solid #c6c6c6; float: left; text-align: center; line-height: 0.5rem; position: relative; padding: 0.1rem 0;
        &:before{content: ""; border-right:1px solid #ddd; right:0; position: absolute; height: 100%; top:0;}
        &.bef:before{ border-color: #8e8e8e;}
        &:last-child{
          &:before{content: ""; border-right:none; }
        }
      }
    }

    .bet-table-c{
      text-align: center;
      ul{
        &.bef{
            li:last-child:before{ border-right: none;}
        }
        li{ position: relative; line-height: .5rem; width:11.1%; font-size:.26rem; border-bottom:1px solid #c6c6c6; height: .5rem; float: left; text-align: center; position: relative; padding: 0.1rem 0;
            i{height:.4rem; width:.4rem; color:#fff; border-radius: 50%; line-height: .4rem; background-color: #dd2638; display: inline-block;}
            &:before{content: ""; border-right:1px solid #ddd; right:0; position: absolute; height: 100%; top:0;}
            &:last-child{cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat center center;   background-size: .5rem; }
            &.active{ background: url('../../assets/images/icon/checked.png') no-repeat center center;   background-size: .5rem; }
            &:last-child:before{ border-color: #8e8e8e;}
        }
      }

    }

    .bet-footer{

      position: fixed; bottom: 1.18rem; width:100%;  
      display: flex;
      li{flex:1; text-align: center; font-size:.24rem; cursor: pointer; -webkit-box-shadow: 0px -3px 2px 0px #E7BFC3;;  box-shadow: 0px -3px 2px 0px #E7BFC3;; border-radius: 5px 5px 0 0;  height:.65rem; line-height: .6rem;  background: url('../../assets/images/icon/bet-f.jpg') repeat-x; background-size: contain;
        i{height:.28rem; width:.28rem; display: inline-block; vertical-align: sub; margin-right:.1rem;}
        &:last-child{background: url('../../assets/images/icon/bet-f-a.jpg') repeat-x; color:#fff;}
        &:nth-child(1) i{background: url('../../assets/images/icon/bet-footer-1.png') no-repeat; background-size: cover; }
        &:nth-child(2) i{background: url('../../assets/images/icon/bet-footer-2.png') no-repeat; background-size: cover; }
        &:nth-child(3) i{background: url('../../assets/images/icon/bet-footer-3.png') no-repeat; background-size: cover; }
      } 
    }


</style>