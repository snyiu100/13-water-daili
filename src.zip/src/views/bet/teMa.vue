<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" :title="title"><router-link to="/" slot="left" class="go-back"></router-link><span slot="right" class="cur"><router-link to="/rules">规则</router-link></span></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
         <bet-header></bet-header>
          <div class="temaA-t bgff">
                <div :class="teMaState=='1'?'active':''" @click="xiaZhu(1)">自选下注</div>
                <div :class="teMaState=='2'?'active':''" @click="xiaZhu(2)">快捷下注</div>
          </div>
          <m-warp :isHei="true">
                <div class="bet-table bgff">
                  <ul class="bet-table-h"><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li>金额</li></ul>
                  <div class="bet-table-c bgff clearfix " :class="teMaState==1?'bet-table-no-chek':''">
                      <ul class="" v-for="(vm,index) in lists.data" :key="index">
                        <li><i :class="'bet-bg-'+vm.cate">{{vm.val}}</i></li>
                        <li>{{vm.Odds}}</li>
                        <li :class="vm.check?'active':''" @click="onOdd(vm)"><t-input v-model="vm.money" v-if="teMaState==1" ></t-input></li>
                      </ul>
                  </div>
                </div>
                <ul class="bet-table-h bgff clear mt15"><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li>金额</li></ul>
                <div class="teMaTable clearfix"  :class="teMaState==1?'bet-table-no-chek':''">
                    <ul class="" v-for="(vm,index) in lists.down" :key="index">
                      <li>{{vm.val}}</li>
                      <li>{{vm.Odds}}</li>
                      <li :class="vm.check?'active':''" @click="onOddDown(vm)"><t-input v-model="vm.money" v-if="teMaState==1" ></t-input></li>
                    </ul>      
                </div>
        </m-warp>
      </div>
      <bet-model v-model="isModel" @on-confirm="savePayBet" :inputShow="inputModel" :info="betArr"></bet-model>
      <bet-footer></bet-footer>
  </div>

</template>

<script>
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import service from '@/common/service'
import TInput from '@/components/t-input'
import {shengXiaoDate,shengXiaoCheckDate} from '@/common/bet'
import {isBet} from "@/common/state"
import BetFooter from './betFooter'
import BetHeader from './betHeader'
import BetModel from './betModel'
export default {
  components:{
    MHeader,
    MWarp,
    BetFooter,
    BetHeader,
    BetModel,
    TInput
  },
  data () {
    return {
        isbet:isBet,
        teMaState:1,  //1:自选下注  2:快捷下注
        title:'特码 特码A',
        lists:[],
        isModel:false,   //模态框状态
        inputModel:true,
        betArr:{bet:[],data:[]},
        info:{
          up:[],
          down:[],
          betting_lx:[{type: 1,two_type: 0,three_type: 0,money: '0',fast:1}]
        }
    }
  },
  watch: {
    //监听路由地址
    $route (to, from) {
      this.info.betting_lx[0].type = to.params.level;
      if(to.params.level=="1" || to.params.level==1){
         this.title = '特码 特码A';
      }else{
         this.title = '特码 特码B';
      } 
      this.betShow();
    }
  },
  created(){   
      if(this.$route.params.level =="1" || this.$route.params.level ==1){
         this.title = '特码 特码A';
      }else{
         this.title = '特码 特码B';
      } 
      this.betShow();

  },
  methods:{
    //选项
    xiaZhu(type){
      this.inputModel = type=='1'?true:false;
      this.info.betting_lx[0].fast = type;
      this.teMaState = type;
    },
    //选择种类
    onOdd(vm){
        if(this.teMaState==1) return false;
        let index = this.lists.data.indexOf(vm);
        if(vm.check){
            this.lists.data[index].check = false;
        }else{
            this.lists.data[index].check = true;
        }
    },
    //选择种类
    onOddDown(vm){
        if(this.teMaState==1) return false;
        let index = this.lists.down.indexOf(vm);
        if(vm.check){
            this.lists.down[index].check = false;
        }else{
            this.lists.down[index].check = true;
        }
    },
    //获取数据
    betShow(){
      this.$http('bet/bet_show',{level:this.info.betting_lx[0].type}).then(res=>{
          if(res.code==200){
            for(let i in res.data){
              res.data[i].check = false;
              res.data[i].money = '';
            }
            for(let i in res.down){
              res.down[i].check = false;
              res.down[i].money = '';
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    //提交下注
    betSave(){
      if(this.teMaState==1 || this.teMaState=='1'){ //判断自助下注   快捷下注
          this.info.up =  shengXiaoDate(this.lists.data);  
          this.info.down =  shengXiaoDate(this.lists.down);
      }else{
         this.info.up =  shengXiaoCheckDate(this.lists.data);
         this.info.down =  shengXiaoCheckDate(this.lists.down);
      }

      if(this.info.up.length<1 && this.info.down.length<1){
            service.openToast(true,"尚未输入金额");
            return false;
      }

      console.log(this.info.betting_lx[0].type+":"+this.title,this.info);
      service.betOrder(this.info).then(res=>{
          if(res.code==200){
              this.isModel = true;
              this.betArr = res;
          }else service.openToast(true,res.msg);
      })
    },
    //弹出框下注
    savePayBet(){

    },
     //清空设置
    clearAll(){
        for(let i in this.lists.data){
            this.lists.data[i].check = false;
            this.lists.data[i].money = '';
        }
        for(let i in this.lists.down){
              this.lists.down[i].money = '';
        }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

    .bet-table-h{ 
      li{ width:11.1%; font-size:.26rem; border-bottom:1px solid #c6c6c6; border-top:1px solid #c6c6c6; float: left; text-align: center; line-height: 0.5rem; position: relative; padding: 0.1rem 0;
        &:before{content: ""; border-right:1px solid #ddd; right:0; position: absolute; height: 100%; top:0;}
        &.bef:before{ border-color: #8e8e8e;}
        &:last-child{
          &:before{content: ""; border-right:none; }
        }
      }
    }

    .bet-table-c{
      &.bet-table-no-chek{
        li{
          input{width:100%; background-color: transparent; text-align: center; border:none; height:100%;}
          &:last-child{cursor: pointer; background: none;   background-size: .5rem; }
        }
      }
      text-align: center;
      ul{
        &.bef{
            li:last-child:before{ border-right: none;}
        }
        li{ position: relative; line-height: .5rem; width:11.1%; font-size:.26rem; border-bottom:1px solid #c6c6c6; height: .5rem; float: left; text-align: center; position: relative; padding: 0.1rem 0;
            i{height:.4rem; width:.4rem; color:#fff; border-radius: 50%; line-height: .4rem; background-color: #dd2638; display: inline-block;}
            &:before{content: ""; border-right:1px solid #ddd; right:0; position: absolute; height: 100%; top:0;}
            &:last-child{cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat center center;   background-size: .5rem; }
            &.active{ background: url('../../assets/images/icon/checked.png') no-repeat center center;   background-size: .5rem; }
            &:last-child:before{ border-color: #8e8e8e;}
        }
      }

    }

.temaA-t{
  display:flex; height:0.8rem;
  div{
    cursor: pointer;
    flex:1;
    text-align: center;
    font-size: .26rem;
    line-height: .76rem;
    border-right:1px solid #c6c6c6;
  }
  div:last-child{border-right:0;};
  .active{border-bottom: 3px solid #ff5047}
}

.teMaTable{
    margin-bottom:0.2rem;

        &.bet-table-no-chek{
          li{
            input{width:100%; background-color: transparent; text-align: center; border:none; height:100%;}
            &:last-child{cursor: pointer; background: #fff; }
          }
        }

        ul{ font-size:.24rem; background-color: #fff; 
          li{
            &:last-child{cursor: pointer; background: url('../../assets/images/icon/check.png') #fff no-repeat center center;   background-size: .5rem; }
            &.active{ background: url('../../assets/images/icon/checked.png') no-repeat center center;   background-size: .5rem; }
            input{background-color: transparent; text-align: center; border:none; width:100%;}
            width: 11.1%; border-bottom:1px solid #c6c6c6; background-color: #fff; height: .5rem; line-height: .5rem; text-align: center; float:left; position: relative; padding: 0.1rem 0; line-height: 0.5rem;
              &::before{
                content: "";
                border-right: 1px solid #ddd;
                right: 0;
                position: absolute;
                height: 100%;
                top: 0;
              }
              &:last-child{
                   &::before{
                     border-color: #8e8e8e;
                   }
              }
          }
        }
  }


.bet-footer{
  position: fixed; bottom: 1.18rem; width:100%;  
  display: flex;
  li{flex:1; text-align: center; font-size:.24rem; cursor: pointer; -webkit-box-shadow: 0px -3px 2px 0px #E7BFC3;;  box-shadow: 0px -3px 2px 0px #E7BFC3;; border-radius: 5px 5px 0 0;  height:.65rem; line-height: .6rem;  background: url('../../assets/images/icon/bet-f.jpg') repeat-x; background-size: contain;
    i{height:.28rem; width:.28rem; display: inline-block; vertical-align: sub; margin-right:.1rem;}
    &:last-child{background: url('../../assets/images/icon/bet-f-a.jpg') repeat-x; color:#fff;}
    &:nth-child(1) i{background: url('../../assets/images/icon/bet-footer-1.png') no-repeat; background-size: cover; }
    &:nth-child(2) i{background: url('../../assets/images/icon/bet-footer-2.png') no-repeat; background-size: cover; }
    &:nth-child(3) i{background: url('../../assets/images/icon/bet-footer-3.png') no-repeat; background-size: cover; }
  } 
}

</style>