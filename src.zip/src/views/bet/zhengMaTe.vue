<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" :title="title"><router-link to="/" slot="left" class="go-back"></router-link><span slot="right" class="cur"><router-link to="/rules">规则</router-link></span></m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
          <bet-header></bet-header>
          <m-warp class="bgff">
             <div class="bet-tez clearfix bet-w-3"><ul class="bet-tez-check"><li :class="vm.check?'active':''" v-for="(vm,index) in lists.zm" @click="tezActive(vm)" :key="index">{{vm.category}}</li></ul></div>
            <div class="bet-table">
               <ul class="bet-table-h"><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li>金额</li></ul>
               <div class="bet-table-c bgff clearfix bet-table-no-chek" >
                  <ul class="" v-for="(vm,index) in lists.data" :key="index">
                    <li><i :class="'bet-bg-'+vm.cate">{{vm.val}}</i></li>
                    <li>{{vm.Odds}}</li>
                    <li><t-input v-model="vm.money"></t-input></li>
                  </ul>
               </div>
            </div>

            <ul class="bet-table-h bgff clear" style="margin-top:.35rem;"><li class="cdd2">名称</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li class="bef">金额</li><li class="cdd2">号码</li><li>赔率</li><li>金额</li></ul>
            <div class="teMaTable clearfix">
                <ul class="" v-for="(vm,index) in lists.ext" :key="index">
                  <li>{{vm.category}}</li>
                  <li>{{vm.Odds}}</li>
                  <li><t-input v-model="vm.money"></t-input></li>
                </ul>      
            </div>
         </m-warp>
      </div>
      <bet-model v-model="isModel" @on-confirm="savePayBet" :info="betArr"></bet-model>
      <bet-footer></bet-footer>
  </div>

</template>

<script>
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import service from '@/common/service'
import {shengXiaoDate} from '@/common/bet'
import {isBet} from "@/common/state"
import TInput from '@/components/t-input'
import BetFooter from './betFooter'
import BetHeader from './betHeader'
import BetModel from './betModel'
export default {
  components:{
    MHeader,
    MWarp,
    BetFooter,
    BetHeader,
    BetModel,
    TInput
  },
  data () {
    return {
        isbet:isBet,
        title:'正码 特',
        level:this.$route.params.level||14,
        lists:[],
        betArr:{bet:[],data:[]},
        isModel:false,
        info:{
          up:[],
          down:[],
          betting_lx:[{type:14,two_type:0,three_type: 0,money: '0',fast:1}]
        }
    }
  },
  created(){   
        this.betShow();

  },
  methods:{
    tezActive(vm){
      let index = this.lists.zm.indexOf(vm);
      for(let i in this.lists.zm){
        this.lists.zm[i].check=false;
      }
      this.info.betting_lx[0].two_type = vm.id;
      this.lists.zm[index].check=true;
      this.betZmt();
    },
    //获取数据
    betShow(){
      this.$http('bet/bet_show',{level:this.level}).then(res=>{
          if(res.code==200){
            for(let i in res.zm){
              if(i==0){
                 res.zm[i].check = true;
              }else res.zm[i].check = false;
              
            }
            for(let i in res.data){
              res.data[i].money = '';
            }
            for(let i in res.ext){
              res.ext[i].money = '';
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    betZmt(){
         this.$http('bet/zmt',{id:this.info.betting_lx[0].two_type}).then(res=>{
              if(res.code ==200){
                for(let i in res.data){
                  res.data[i].money = '';
                }
                this.lists.data = res.data;
              }
         })
    },
    //提交下注
    betSave(){  
      this.info.up =  shengXiaoDate(this.lists.data);
      this.info.down =  shengXiaoDate(this.lists.ext);
      if(this.info.up.length<1){
          service.openToast(true,"尚未输入金额");
          return false;
      } 
      console.log("14:正码 特",this.info);
      service.betOrder(this.info).then(res=>{
          if(res.code==200){
              this.isModel = true;
              this.betArr = res;
              this.betShow();
          }else service.openToast(true,res.msg);
      })
    },
    //弹出框下注
    savePayBet(){

    },
    //清空设置
    clearAll(){
        for(let i in this.lists.data){
          this.lists.data[i].money = '';
        }
        for(let i in this.lists.ext){
          this.lists.ext[i].money = '';
        }

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>


    .bet-table-h{ 
      li{ width:11.1%; font-size:.26rem; border-bottom:1px solid #c6c6c6; border-top:1px solid #c6c6c6; float: left; text-align: center; line-height: 0.5rem; position: relative; padding: 0.1rem 0;
        &:before{content: ""; border-right:1px solid #ddd; right:0; position: absolute; height: 100%; top:0;}
        &.bef:before{ border-color: #8e8e8e;}
        &:last-child{
          &:before{content: ""; border-right:none; }
        }
      }
    }

    .bet-table-c{
      &.bet-table-no-chek{
        li{
          &:last-child{cursor: pointer; background: none;   background-size: .5rem; }
        }
      }
      text-align: center;
      ul{
        &.bef{
            li:last-child:before{ border-right: none;}
        }
        li{ position: relative; line-height: .5rem; width:11.1%; font-size:.26rem; border-bottom:1px solid #c6c6c6; height: .5rem; float: left; text-align: center; position: relative; padding: 0.1rem 0;
            input[type='number']{height:100%; width:100%; border:none; text-align: center; font-size:0.26rem;}
            i{height:.4rem; width:.4rem; color:#fff; border-radius: 50%; line-height: .4rem; background-color: #dd2638; display: inline-block;}
            &:before{content: ""; border-right:1px solid #ddd; right:0; position: absolute; height: 100%; top:0;}
            //&:last-child{cursor: pointer; background: url('../../assets/images/icon/check.png') no-repeat center center;   background-size: .5rem; }
            &.active{ background: url('../../assets/images/icon/checked.png') no-repeat center center;   background-size: .5rem; }
            &:last-child:before{ border-color: #8e8e8e;}
        }
      }

    }

.temaA-t{
  display:flex;
  div{
    cursor: pointer;
    flex:1;
    text-align: center;
    font-size: .26rem;
    line-height: .76rem;
    border-right:1px solid #c6c6c6;
  }
  div:last-child{border-right:0;};
  .active{border-bottom: 3px solid #ff5047}
}

.teMaTable{
    margin-bottom:.2rem;
        ul{ font-size:.24rem; background-color: #fff; 
          li{
            width: 11.1%; border-bottom:1px solid #c6c6c6; background-color: #fff; text-align: center; float:left; position: relative; padding: 0.1rem 0; line-height: 0.5rem;
               input[type='number']{height:100%; font-size:.26rem; width:100%; border:none; text-align: center;}
              &::before{
                content: "";
                border-right: 1px solid #ddd;
                right: 0;
                position: absolute;
                height: 100%;
                top: 0;
              }
              &:last-child{
                   &::before{
                     border-color: #8e8e8e;
                   }
              }
          }
        }
  }


.bet-footer{
  position: fixed; bottom: 1.18rem; width:100%;  
  display: flex;
  li{flex:1; text-align: center; font-size:.24rem; cursor: pointer; -webkit-box-shadow: 0px -3px 2px 0px #E7BFC3;;  box-shadow: 0px -3px 2px 0px #E7BFC3;; border-radius: 5px 5px 0 0;  height:.65rem; line-height: .6rem;  background: url('../../assets/images/icon/bet-f.jpg') repeat-x; background-size: contain;
    i{height:.28rem; width:.28rem; display: inline-block; vertical-align: sub; margin-right:.1rem;}
    &:last-child{background: url('../../assets/images/icon/bet-f-a.jpg') repeat-x; color:#fff;}
    &:nth-child(1) i{background: url('../../assets/images/icon/bet-footer-1.png') no-repeat; background-size: cover; }
    &:nth-child(2) i{background: url('../../assets/images/icon/bet-footer-2.png') no-repeat; background-size: cover; }
    &:nth-child(3) i{background: url('../../assets/images/icon/bet-footer-3.png') no-repeat; background-size: cover; }
  } 
}

.bet-w-3 {
  li{width:33.3%;}
}

</style>