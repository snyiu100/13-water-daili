<template>
  <div class="td-warp">
      <m-header :showBack="false" :downShow="true" title="特码生肖">
        <router-link to="/" slot="left" class="go-back">
        </router-link><span slot="right" class="cur"><router-link to="/rules">规则</router-link></span>
      </m-header>
      <div class="tb-content-warp" :class="isIos?'iosMarginTop':''">
         <bet-header></bet-header>
         <m-warp class="bgff">
               <div class="bet-table-hexiao bgff no-check">
                  <ul class="clearfix bet-table-hexiao-header">
                    <li>号码</li>
                    <li>赔率</li>
                    <li>生肖</li>
                    <li>金额</li>
                  </ul>
                  <ul class="clearfix" v-for="(vm,index) in lists.data" :key="index">
                    <li><span v-for="(arr,index) in vm.arr" :key="index" :class="'bet-bg-'+arr.cate">{{arr.key}}</span></li>
                    <li>{{vm.Odds}}</li>
                    <li>{{vm.category}}</li>
                    <li><t-input v-model="vm.money"></t-input></li>
                  </ul>
               </div>
            </m-warp>
         </div>
      <bet-model v-model="isModel" @on-confirm="savePayBet" :info="betArr"></bet-model>
      <bet-footer></bet-footer>
  </div>

</template>

<script>
import {dates,shengXiaoDate} from '@/common/bet'
import {isBet} from "@/common/state"
import service from '@/common/service'
import TInput from '@/components/t-input'
import MHeader from '@/components/header'
import MWarp from '@/components/warp'
import BetFooter from './betFooter'
import BetHeader from './betHeader'
import BetModel from './betModel'
export default {
  components:{
    MHeader,
    MWarp,
    BetFooter,
    BetHeader,
    BetModel,
    TInput
  },
  data () {
    return {
      isbet:isBet,
      lists:[],
      isModel:false,
      betArr:{bet:[],data:[]},
      info:{
        up:[{id:'',money:''}],
        down:[],
        betting_lx:[{type: 7,two_type: 0,three_type: 0,money: '0',fast:1}]
      }
    }
  },
  created(){   
    this.betShow();
  },
  methods:{
    //获取数据
    betShow(){
      this.$http('bet/bet_show',{level:7}).then(res=>{
          if(res.code==200){
            for(let i in res.data){
              res.data[i].arr = dates[i];
              res.data[i].money = '';
            }
            this.lists = res;
          }else  service.openToast(true,res.msg);
      })  
    },
    //提交下注
    betSave(){
      this.info.down =  shengXiaoDate(this.lists.data);
      if(this.info.down.length<1){
          service.openToast(true,"尚未输入金额");
          return false;
      } 
      console.log("7:特码生肖",this.info);
      service.betOrder(this.info).then(res=>{
          if(res.code==200){
              this.isModel = true;
              this.betArr = res;
              this.betShow();
          }else service.openToast(true,res.msg);
      })
    },
    //弹出框下注
    savePayBet(){

    },
    //清空设置
    clearAll(){
        for(let i in this.lists.data){
            this.lists.data[i].money = '';
        }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

.bet-table-hexiao{
    border-top:1px solid #c6c6c6;

  ul{
    &.bet-table-hexiao-header{
      li{text-align: center; text-indent:0;   line-height:0.8rem;
        &:first-child{width:55%; text-align: center;}
        &::after{content: ""; border-right:1px solid #c6c6c6; float: right; height:0.8rem;}
        &:nth-child(4){ background: none;}
       }
    }
    border-bottom:1px solid #c6c6c6;
    li{ width:15%; float:left; text-align: center;  font-size:0.26rem;
      input{height:100%; width:100%; text-align: center; border:none; background-color: transparent;}
      &:last-child::after{border-right:none; }
      &::after{content: ""; border-right:1px solid #c6c6c6; float: right; height:0.8rem;}
      &:nth-child(2),&:nth-child(3){line-height: 0.8rem;}
      &:nth-child(4){ height: 0.8rem; cursor: pointer;}
      &:first-child{width:55%; text-align: left;
        span{background-color: #dd2638;  height:.45rem; margin: .18rem 0 0 .25rem; width:.45rem; line-height: .48rem; color:#fff; border-radius: 50%; display: inline-block; font-size:0.24rem; text-align: center;}
      }
    }
  }
}

.bet-w-4 {
  li{width:25%;}
}

</style>