<template>
  <div class="td-warp">
        <m-header title="资讯" :showBack="true"></m-header>
        <div class="tb-content-warp" style="padding-bottom:1.2rem;" :class="isIos?'iosMarginTop':''">
            <ul class="news">
              <li v-for="(vm,index) in info" :key="index"><img :src="vm" style="border:none;"></li>
            </ul>
        </div>

  </div>
</template>

<script>
import MHeader from '@/components/header'
import storage from '@/common/localStorage'
export default {
  components:{
    MHeader
  },
  data () {
    return {
      info:[]
    }
  },
  created(){   
    this.info = storage.getItem('news')
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
   .news{
      img{ width:100%; margin-bottom: 10px;}
   }
</style>
