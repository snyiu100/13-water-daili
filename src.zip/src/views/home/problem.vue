
<template>
  <div class="td-warp">
       <m-header :showBack="true" title="常见问题"></m-header>
       <div class="tb-content-warp" style="padding-bottom:1.2rem;" :class="isIos?'iosMarginTop':''">
            <ul class="problem">
                <li><p>1、投注记录和中奖记录</p>投注记录和中奖记录只显示最近7天内的数据</li>
                <li><p>2、充值记录</p>充值记录只显示最近 三个月的数据</li>
                <li><p>3、提现记录</p>提现记录只显示最近三个月的数据</li>
                <li><p>4、充值问题</p>充值出现未到账的问题，请咨询顶部的客服。线下充值，请先打款在提交打款记录。不然怕出现后台审核打款记录时，用户银行打款记录还未到账。</li>
                <li><p>5、账号冻结</p>发现投注异常、异常资金投注等行为，会进行投注冻结，若被冻结，请咨询客服人员</li>
                <li><p>6、提现须知</p>只有当用户的流水金额大于提现金额，才可以提现，用户提现需要等后台审核完成，才可以提现下一笔</li>
                <li><p>7、投注冻结</p>发现投注异常，异常资金投注行为，会进行投注冻结，若被 冻结，请咨询客服人员</li>
                <li><p>8、彩种规则</p>每个彩种的玩法规则，在每个彩种的投注页面右上角的“规则”</li>
                <li><p>9、忘记登录密码</p>
已注册的用户，如果忘记登录密码，请在登录页面点击下方的忘记密码，找回密码。
温馨提示：为保障用户账户安全，客服不提供修改密码的服务。</li>
                <li><p>10、忘记提现密码</p>请查找客服修改、不过要提供最近投注金额、充值金额等信息</li>
            </ul>
       </div>
  </div>
</template>

<script>
import MHeader from '@/components/header'
export default {
  components:{
    MHeader
  },
  methods:{

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.problem li{background-color: #fff; margin-bottom: 0.15rem; padding:0.2rem; font-size:0.26rem;}
.problem li p{border-bottom:1px solid #efefef; padding-bottom: 0.1rem; margin-bottom:0.2rem; font-size:.28rem;}
</style>
